<?php

/*
is.php
�slenska - Icelandic
Translation by "KinD"
*/

$words = array(
'index of' => 'Efnisyfirlit af',
'parent directory' => 'Til baka',
'file' => 'Skr�r',
'size' => 'St�r�',
'modified' => 'Breytt',
'total size' => 'Heildar St�r�',
'total files' => 'Heildar Skr�r',
'total folders' => 'Heildar m�ppur',
'search' => 'Leita af',
'files' => 'Skr�r',
'folders' => 'M�ppur',
'both' => 'B��i',
'search results' => '�etta Fannst',
'no results' => 'EKKERT FANNST',
'end of results' => 'Leit h�tt',
'found' => 'fundust');

?>