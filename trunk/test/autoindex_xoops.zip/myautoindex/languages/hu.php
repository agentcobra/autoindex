<?php

/*
hu.php
Magyar - Hungarian
Translation by crash2@freemail.hu and "Blaize"
*/

$words = array(
'index of' => 'K&ouml;nyvt&aacute;r',
'parent directory' => 'Feljebb',
'file' => 'F&aacute;jl',
'size' => 'M&eacute;ret',
'modified' => 'D&aacute;tum',
'total size' => '&Ouml;sszes m&eacute;ret',
'total files' => '&Ouml;sszes file',
'total folders' => '&Ouml;sszes k&ouml;nyvt&aacute;r',
'search' => 'Keres',
'files' => 'F&aacute;jl',
'folders' => 'K&ouml;nyvt&aacute;r',
'both' => 'Mind',
'search results' => 'Keres&eacute;s eredm&eacute;nye',
'no results' => 'NINCS TAL&Aacute;LAT',
'end of results' => 'Keres&eacute;s v&eacute;ge',
'found' => 'tal&aacute;lat');

?>