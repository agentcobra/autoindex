﻿<?php

/*
ko.php
한국어 - Korean
Translation by "Pandix"
*/

$words = array(
'index of' => 'Index of',
'parent directory' => '상위 디렉터리',
'file' => '파일',
'size' => '크기',
'modified' => '파일',
'total size' => '전체 크기',
'total files' => '전체 파일',
'total folders' => '전체 폴더',
'search' => '검색',
'files' => '파일',
'folders' => '폴더',
'both' => '모두',
'search results' => '검색 결과',
'no results' => '검색 결과가 없습니다',
'end of results' => '검색 끝',
'found' => '개 찾았습니다');

?>