<?php

/*
ro.php
Rom�n� - Romanian
Translation by BuGsY (streetlaw@as.ro)
*/

$words = array(
'index of' => 'Indice la',
'parent directory' => 'Director Superior',
'file' => 'Fisier',
'size' => 'Marime',
'modified' => 'Modificat',
'total size' => 'Dimensiune totala',
'total files' => 'Fisiere totale',
'total folders' => 'Foldere totale',
'search' => 'Cauta',
'files' => 'Fisiere',
'folders' => 'Foldere',
'both' => 'Ambele',
'search results' => 'Rezultatele cautari',
'no results' => 'CAUTARE FARA REZULTATE',
'end of results' => 'Sfarsitul rezultatelor',
'found' => 'rezultat(e)');

?>