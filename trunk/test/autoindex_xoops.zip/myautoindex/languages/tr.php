<?php

/*
tr.php
T�rk�e - Turkish
Translation by Sinan Kesk�n
*/

$words = array(
'index of' => '��indekiler',
'parent directory' => 'Ana Dizin',
'file' => 'Dosya',
'size' => 'Boyut',
'modified' => 'De�i�tirilme',
'total size' => 'Toplam boyut',
'total files' => 'Toplam dosya',
'total folders' => 'Toplam klas�r',
'search' => 'Arama',
'files' => 'Dosya',
'folders' => 'Klas�r',
'both' => 'Her �kiside',
'search results' => 'Arama Sonu�lar�',
'no results' => 'SONU� BULUNAMADI',
'end of results' => 'Araman�n sonu',
'found' => 'bulundu');

?>