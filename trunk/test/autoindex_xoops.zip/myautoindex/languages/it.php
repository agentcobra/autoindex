<?php

/*
it.php
Italiano - Italian
Translation by "Sharko" and Fabrizio De Santis
*/

$words = array(
'index of' => 'Indice di',
'parent directory' => 'Directory Superiore',
'file' => 'File',
'size' => 'Dimensione',
'modified' => 'Modificato',
'total size' => 'Dimensione totale',
'total files' => 'Files totali',
'total folders' => 'Cartelle totali',
'search' => 'Cerca',
'files' => 'Files',
'folders' => 'Cartelle',
'both' => 'Tutto',
'search results' => 'Risultati della ricerca',
'no results' => 'NESSUN RISULTATO TROVATO',
'end of results' => 'Fine della ricerca',
'found' => 'trovati',
'upload' => 'Manda',
'go' => 'Vai',
'to this folder' => 'in questa cartella');

?>