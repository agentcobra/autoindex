<?php

/*
da.php
Dansk - Danish
Translation by Lars Dyrelund
*/

$words = array(
'index of' => 'Indhold af',
'parent directory' => 'Niveau op',
'file' => 'Fil',
'size' => 'St&oslash;rrelse',
'modified' => '&AElig;ndret',
'total size' => 'Total st&oslash;rrelse',
'total files' => 'Total antal filer',
'total folders' => 'Total antal mapper',
'search' => 'S&oslash;g',
'files' => 'Filer',
'folders' => 'Mapper',
'both' => 'Begge',
'search results' => 'Resultat af s&oslash;gning',
'no results' => 'INGEN RESULTATER',
'end of results' => 'Ikke flere resultater',
'found' => 'fundet');

?>