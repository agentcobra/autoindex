<?php

/*
fr.php
Fran�ais - French
Translation by Pierre Lesbazeilles
*/

$words = array(
'index of' => 'Chemin',
'parent directory' => 'Dossier Parent',
'file' => 'Fichier',
'size' => 'Taille',
'modified' => 'Modifi&eacute;',
'total size' => 'Taille totale',
'total files' => 'Nombre de fichiers',
'total folders' => 'Nombre de dossiers',
'search' => 'Rechercher',
'files' => 'Fichiers',
'folders' => 'Dossiers',
'both' => 'Les deux',
'search results' => 'R&eacute;sultat de la recherche',
'no results' => 'Pas de r&eacute;sultat',
'end of results' => 'Fin de la recherche',
'found' => 'trouv&eacute;');

?>