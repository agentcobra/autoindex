﻿<?php

/*
he.php
עיברית - Hebrew
Translated by "Shlomi Tolpoler - www.topler.de.vu"
*/

$words = array(
'index of' => 'אינדקס של',
'parent directory' => 'תיקיה ראשית',
'file' => 'שם הקובץ',
'size' => 'גודל הקובץ',
'modified' => 'שינוי האחרון',
'total size' => 'סהכ גודל',
'total files' => 'סהכ קבצים',
'total folders' => 'סהכ תיקיות',
'search' => 'חפוש',
'files' => 'קבצים',
'folders' => 'תיקיות',
'both' => 'שניהם',
'search results' => 'תוצאות החיפוש',
'no results' => 'אין תוצאות החיפוש',
'end of results' => 'סוף החיפוש',
'found' => 'נמצאו');

?>