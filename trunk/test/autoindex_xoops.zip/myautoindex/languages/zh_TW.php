<?php

/*
zh_TW.php
漢語 - Chinese Traditional (Big5)
Translation by Michael Lui
*/

$words = array(
'index of' => '索引',
'parent directory' => '上一級目錄',
'file' => '文件',
'size' => '大小',
'modified' => '最後修改日期',
'total size' => '佔用總空間',
'total files' => '總文件數',
'total folders' => '總目錄數',
'search' => '搜索',
'files' => '文件',
'folders' => '目錄',
'both' => '兩者都有',
'search results' => '搜索結果',
'no results' => '沒有找到你要的',
'end of results' => '搜索結束',
'found' => '尋找');

?>