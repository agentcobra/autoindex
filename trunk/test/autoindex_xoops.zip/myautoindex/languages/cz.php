<?php

/*
cz.php
Cesky - Czech
Translation by Vasek Purchart
*/

$words = array(
'index of' => 'Seznam',
'parent directory' => 'Nadrazeny adresar',
'file' => 'Soubor',
'size' => 'Velikost',
'modified' => 'Upraveny',
'total size' => 'Celokva velikost',
'total files' => 'Celkem souboru',
'total folders' => 'Celkem slozek',
'search' => 'Search',
'files' => 'Soubory',
'folders' => 'Slozka',
'both' => 'Oba',
'search results' => 'Vysledky vyhledavani',
'no results' => 'Nenalezeny zadne vysledky',
'end of results' => 'Konec vyhledavani',
'found' => 'Nalezeno');

?>