<?php

/*
lv.php
Latvie�u - Latvian
Translation by Arnis Rug�js (arnis@mediaservice.lv)
*/

$words = array(
'index of' => 'Mape:',
'parent directory' => 'Aug&#353;up',
'file' => 'Fails',
'size' => 'Izm&#275;rs',
'modified' => 'Datums',
'total size' => 'Kop&#275;jais apjoms',
'total files' => 'Faili kop&#257;',
'total folders' => 'Mapes kop&#257;',
'search' => 'Mekl&#275;t',
'files' => 'Faili',
'folders' => 'Mapes',
'both' => 'Abos',
'search results' => 'Mekl&#275;&#353;anas rezult&#257;ti',
'no results' => 'NAV NEKAS ATRASTS',
'end of results' => 'Mekl&#275;&#353;anas beigas',
'found' => 'atrasti');

?>