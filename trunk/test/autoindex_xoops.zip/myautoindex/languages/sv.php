<?php

/*
sv.php
Svenska - Swedish
Translation by Christian Lilja
*/

$words = array(
'index of' => 'Inneh&aring;ll',
'parent directory' => 'Upp en niv&aring;',
'file' => 'Fil',
'size' => 'Storlek',
'modified' => 'Modifierad',
'total size' => 'Total storlek',
'total files' => 'Totalt antal filer',
'total folders' => 'Totalt antal katalogerr',
'search' => 'S&ouml;k',
'files' => 'Filer',
'folders' => 'Mappar',
'both' => 'B&aring;da',
'search results' => 'S&ouml;k resultat',
'no results' => 'INGA RESULTAT FUNNA',
'end of results' => 'Avslutad s&ouml;kning',
'found' => 'hittad');

?>