<?php

/*
sr_CY.php
Serbian (Cyrillic)
Translated by Petar Benke, benke verat net
*/

$words = array(
'index of' => 'ÁÐÔàÖÐø',
'parent directory' => 'ÝØÒÞ ÓÞàÕ',
'file' => 'ÝÐ×ØÒ',
'size' => 'ÒÕÛØçØÝÐ',
'modified' => 'ÔÐâãÜ',
'total size' => 'ãÚãßÝÐ ÒÕÛØçØÝÐ',
'total files' => 'ãÚãßÝÞ ÔÐâÞâÕÚÐ',
'total folders' => 'ãÚãßÝÞ ÔØàÕÚâÞàØøãÜÐ',
'search' => '¿àÕâàÐÖØÒÐúÕ',
'files' => 'ÔÐâÞâÕÚÐ',
'folders' => 'ÔØàÕÚâÞàØøãÜÐ',
'both' => 'Ø øÕÔÝÞ Ø ÔàãÓÞ',
'search results' => 'ÀÕ×ãÛâÐâ ßàÕâàÐÖØÒÐúÐ',
'no results' => '¶ÐÛØÜ, ÝØèâÐ ÝØøÕ ÝÐòÕÝÞ',
'end of results' => '¿àÕâàÖØÒÐúÕ øÕ ÞÚÞÝçÐÝÞ',
'found' => 'ÝÐòÕÝÞ');

?>