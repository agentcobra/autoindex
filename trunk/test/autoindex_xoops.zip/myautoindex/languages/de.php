<?php

/*
de.php
Deutsch - German
Translation by "DazClimax"
Updated by "tagdancer"
*/

$words = array(
'index of' => 'Index von',
'parent directory' => '&Uuml;bergeordnetes Verzeichnis',
'file' => 'Datei',
'size' => 'Gr&ouml;sse',
'modified' => 'Ge&auml;ndert',
'total size' => 'Gesamtgr&ouml;sse',
'total files' => 'Gesamtdateien',
'total folders' => 'Gesamtverzeichnisse',
'search' => 'Suchen',
'files' => 'Dateien',
'folders' => 'Verzeichnisse',
'both' => 'Beide',
'search results' => 'Suchergebnisse',
'no results' => 'KEIN ERGEBNIS GEFUNDEN',
'end of results' => 'Ende der Suche',
'found' => 'gefunden');

?>