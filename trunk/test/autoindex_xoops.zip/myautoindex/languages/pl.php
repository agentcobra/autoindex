<?php

/*
pl.php
Polski - Polish
Translation by Krzysztof Kope�
*/

$words = array(
'index of' => 'Index of',
'parent directory' => 'Katalog macierzysty',
'file' => 'Nazwa zbioru',
'size' => 'Rozmiar',
'modified' => 'Modyfikowany',
'total size' => 'Cakowity rozmiar',
'total files' => 'Ilo&aelig; plik&oacute;w',
'total folders' => 'Ilo&aelig; Katalog&oacute;w',
'search' => 'Szukaj',
'files' => 'Plik',
'folders' => 'Katalog',
'both' => 'Oba',
'search results' => 'Rezultat szukania',
'no results' => 'BRAK REZULTAT&Oacute;W PRZESZUKIWANIA',
'end of results' => 'Koniec przeszukiwania',
'found' => 'znaleziono');

?>