<?php

/*
al.php
Shqip - Albanian
Translation by Laurent Dhima
*/

$words = array(
'index of' => 'Treguesi i',
'parent directory' => 'Directory e M&euml;sip&euml;rme',
'file' => 'File',
'size' => 'Madh&euml;sia',
'modified' => 'Ndryshuar',
'total size' => 'Madh&euml;sia gjithsej',
'total files' => 'Gjithsej Files',
'total folders' => 'Gjithsej Kartela',
'search' => 'K&euml;rko',
'files' => 'Files',
'folders' => 'Kartela',
'both' => 'Gjith�ka',
'search results' => 'Rezultati i k&euml;rkimit',
'no results' => 'NUK U GJET ASNJ&Euml; REZULTAT',
'end of results' => 'Fundi i k&euml;rkimit',
'found' => 'gjetur',
'upload' => 'D&euml;rgo',
'go' => 'Shko',
'to this folder' => 'tek kjo kartel&euml;');

?>