﻿<?php

/*
ru.php
Русский - Russian
Translation by masterr15@ukr.net
*/

$words = array(
'index of' => 'Индекс',
'parent directory' => 'Родительская директория',
'file' => 'Файл',
'size' => 'Объём',
'modified' => 'Изменён',
'total size' => 'Полный объём',
'total files' => 'Всего файлов',
'total folders' => 'Всего папок',
'search' => 'Поиск',
'files' => 'Файлы',
'folders' => 'Папки',
'both' => 'Оба',
'search results' => 'Результаты поиска',
'no results' => 'Поиск не дал результатов',
'end of results' => 'Конец поиска',
'found' => 'Найдено');

?>