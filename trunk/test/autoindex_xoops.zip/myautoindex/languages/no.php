<?php

/*
no.php
Norsk - Norwegian
Translation by Kristian Hansen
*/

$words = array(
'index of' => 'Innhold av',
'parent directory' => 'Niv&aring; opp',
'file' => 'Fil',
'size' => 'St&oslash;rrelse',
'modified' => 'Endret',
'total size' => 'Total st&oslash;rrelse',
'total files' => 'Total antall filer',
'total folders' => 'Total antall mapper',
'search' => 'S&oslash;k',
'files' => 'Filer',
'folders' => 'Mapper',
'both' => 'Begge',
'search results' => 'Resultat af s&oslash;king',
'no results' => 'INGEN RESULTATER',
'end of results' => 'Ikke flere resultater',
'found' => 'funnet');

?>