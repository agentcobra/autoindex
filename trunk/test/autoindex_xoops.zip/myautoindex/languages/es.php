<?php

/*
es.php
Espa�ol - Spanish
Translation by Alan Mizrahi <alan@ldc.usb.ve>
*/

$words = array(
'index of' => '&Iacute;ndice de',
'parent directory' => 'Directorio Superior',
'file' => 'Archivo',
'size' => 'Tama&ntilde;o',
'modified' => 'Modificado',
'total size' => 'Tama&ntilde;o total',
'total files' => 'Archivos totales',
'total folders' => 'Directorios totales',
'search' => 'B&uacute;squeda',
'files' => 'Archivos',
'folders' => 'Directorios',
'both' => 'Ambos',
'search results' => 'Resultados de la b&uacute;squeda',
'no results' => 'NO SE HAN ENCONTRADO RESULTADOS',
'end of results' => 'Fin de la b&uacute;squeda',
'found' => 'encontrados');

?>