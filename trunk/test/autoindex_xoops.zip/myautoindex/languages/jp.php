﻿<?php

/*
jp.php
日本語 - Japanese
Translation by "rainier"
*/

$words = array(
'index of' => '目次',
'parent directory' => '親ディレクトリ',
'file' => 'ファイル',
'size' => 'サイズ',
'modified' => '更新日時',
'total size' => '合計サイズ',
'total files' => '合計ファイル数',
'total folders' => '合計フォルダ数',
'search' => '検索',
'files' => 'ファイル',
'folders' => 'フォルダ',
'both' => '両方',
'search results' => '検索結果',
'no results' => '見つかりません',
'end of results' => '検索結果の最後',
'found' => '見つかりました');

?>