<?php

/*
gr.php
Ελληνικά - Greek
Translation by Dimitris Koukoravas
*/

$words = array(
'index of' => 'Λίστα του',
'parent directory' => 'Προηγούμενο Κατάλογο',
'file' => 'Αρχεία',
'size' => 'Μέγεθος',
'modified' => 'Επεξεργάστηκε',
'total size' => 'Ολικό Μέγεθος',
'total files' => 'Ολικά Αρχεία',
'total folders' => 'Ολικοί Φάκελοι',
'search' => 'Ψάξε',
'files' => 'Αρχεία',
'folders' => 'Φάκελοι',
'both' => 'Και τα 2',
'search results' => 'Αποτελέσματα Ψαξήματος',
'no results' => 'ΔΕΝ ΒΡΈΘΗΚΑΝ ΑΠΟΤΕΛΕΣΜΑΤΑ',
'end of results' => 'Τέλος Ψαξήματος',
'found' => 'Βρέθηκαν');

?>