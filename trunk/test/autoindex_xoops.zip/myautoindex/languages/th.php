﻿<?php

/*
th.php
ไทย - Thai
Translation by "MaXZerker"
*/

$words = array(
'index of' => 'ดัชนี ของ',
'parent directory' => 'ไดเร็กโทรี่ ก่อนหน้า',
'file' => 'ไฟล์',
'size' => 'ขนาด',
'modified' => 'แก้ใข',
'total size' => 'ขนาด ทั้งหมด',
'total files' => 'ไฟล์ ทั้งหมด',
'total folders' => 'โฟลเดอร์ ทั้งหมด',
'search' => 'ค้นหา',
'files' => 'ไฟล์',
'folders' => 'โฟลเดอร์',
'both' => 'ทั่งคู้',
'search results' => 'ผลการค้นหา',
'no results' => 'ค้นหาไม่พบ',
'end of results' => 'จบการค้นหา',
'found' => 'พบ');

?>