<?php

/*
pt_BR.php
Brazilian Portuguese
Translation by Hugo Cisneiros
*/

$words = array(
'index of' => '&Iacute;ndice de',
'parent directory' => 'Diret&atilde;rio Pai',
'file' => 'Arquivo',
'size' => 'Tamanho',
'modified' => 'Modificado',
'total size' => 'Tamanho total',
'total files' => 'Total de arquivos',
'total folders' => 'Total de pastas',
'search' => 'Procurar',
'files' => 'Arquivos',
'folders' => 'Pastas',
'both' => 'Ambos',
'search results' => 'Resultados da Busca',
'no results' => 'NENHUM RESULTADO ENCONTRADO',
'end of results' => 'Fim da busca',
'found' => 'achados');

?>