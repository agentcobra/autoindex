﻿<?php

/*
bg.php
Българска - Bulgarian
Translation by thug@smrad.com
*/

$words = array(
'index of' => 'уЯДЯТЦБОЙЕ ОБ',
'parent directory' => 'зМБЧОБ дЙТЕЛФПТЙС',
'file' => 'жБКМ',
'size' => 'зПМЕНЙОБ',
'modified' => 'нПДЙЖЙГЙТБО',
'total size' => 'пВЭ тБЪНЕТ',
'total files' => 'пВЭП жБКМПЧЕ',
'total folders' => 'пВЭП рБРЛЙ',
'search' => 'фЯТУЙ',
'files' => 'жБКМПЧЕ',
'folders' => 'рБРЛЙ',
'both' => 'оБЧУСЛЯДЕ',
'search results' => 'тЕЪХМФБФЙ ПФ ФЯТУЕОЕФП',
'no results' => 'оСНБ оБНЕТЕОЙ тЕЪХМФБФЙ',
'end of results' => 'лТБК ОБ фЯТУЕОЕФП',
'found' => 'оБНЕТЕОЙ');

?>