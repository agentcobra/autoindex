<?php

/*
it.php
Italiano - Italian
Translation by *.bLLy
*/

$words = array(
'index of' => 'Contenuto di',
'parent directory' => 'Directory Superiore',
'file' => 'File',
'size' => 'Dimensione',
'modified' => 'Modificato',
'total size' => 'Dimensione totale',
'total files' => 'Totale Files',
'total folders' => 'Totale Cartelle',
'search' => 'Cerca',
'files' => 'Files',
'folders' => 'Cartelle',
'both' => 'Entrambi',
'search results' => 'Risultati della ricerca',
'no results' => 'SPIACENTE, LA RICERCA NON HA DATO RISULTATI',
'end of results' => 'Fine dei risultati',
'found' => 'trovati',
'upload' => 'Carica',
'go' => 'Vai',
'to this folder' => 'a questa cartella');

?>