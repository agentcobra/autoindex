<?php

/*
vi.php
Tiếng Việt - Vietnamese
*/

$words = array(
'index of' => 'Index of',
'parent directory' => 'Thư mục cha',
'file' => 'Tập tin',
'size' => 'Kích thước',
'modified' => 'Đã hiệu chỉnh',
'total size' => 'Tổng dung lượng',
'total files' => 'Tập tin',
'total folders' => 'Thư mục',
'search' => 'Tìm kiếm',
'files' => 'Tập tin',
'folders' => 'Thư mục',
'both' => 'Cả hai lọai',
'search results' => 'Kết quả tìm kiếm',
'no results' => 'Tìm kiếm không có kết quả',
'end of results' => 'Kết thúc việc tìm kiếm',
'found' => 'Tìm thấy');

?>