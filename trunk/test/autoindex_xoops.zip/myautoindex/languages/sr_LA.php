<?php

/*
sr_LA.php
Serbian (Latin)
Translated by Petar Benke, benke verat net
*/

$words = array(
'index of' => 'Sadr�aj',
'parent directory' => 'nivo gore',
'file' => 'naziv',
'size' => 'veli�ina',
'modified' => 'datum',
'total size' => 'ukupna veli�ina',
'total files' => 'ukupno datoteka',
'total folders' => 'ukupno direktorijuma',
'search' => 'Pretra�ivanje',
'files' => 'datoteka',
'folders' => 'direktorijuma',
'both' => 'i jedno i drugo',
'search results' => 'Rezultat pretra�ivanja',
'no results' => '�alim, ni�ta nije na�eno',
'end of results' => 'Pretra�ivanje je okon�ano',
'found' => 'na�eno');

?>