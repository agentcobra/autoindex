<?php

/*
ee.php
Eesti - Estonian
Translation by W. District
*/

$words = array(
'index of' => 'Dokumendiloetelu',
'parent directory' => 'Peakataloog',
'file' => 'Dokument',
'size' => 'Suurus',
'modified' => 'Muudetud',
'total size' => 'Suurus kokku',
'total files' => 'Dokumente kokku',
'total folders' => 'Katalooge kokku',
'search' => 'Otsi',
'files' => 'Dokumenti',
'folders' => 'Kataloogi',
'both' => 'M&otilde;lemad',
'search results' => 'Otsingu tulemused',
'no results' => 'Tulemusteta',
'end of results' => 'Otsingu l&otilde;pp',
'found' => 'leitud');

?>