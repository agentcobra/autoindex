<?php

/*
nl.php
Nederlands - Dutch
Translation by Tom Buskens
*/

$words = array(
'index of' => 'Inhoud van',
'parent directory' => 'Omhoog',
'file' => 'Bestand',
'size' => 'Grootte',
'modified' => 'Laatst aangepast',
'total size' => 'Totale grootte',
'total files' => 'Totaal aantal bestanden',
'total folders' => 'Total aantal mappen',
'search' => 'Zoeken',
'files' => 'Bestanden',
'folders' => 'Mappen',
'both' => 'Beide',
'search results' => 'Zoekresultaten',
'no results' => 'GEEN RESULTATEN GEVONDEN',
'end of results' => 'Einde resultaten',
'found' => 'gevonden');

?>