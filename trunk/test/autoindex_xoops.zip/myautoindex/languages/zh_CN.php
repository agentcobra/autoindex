﻿<?php

/*
zh.php
汉语 - Chinese
Translation by Allen Chen
*/

$words = array(
'index of' => '索引',
'parent directory' => '上一级目录',
'file' => '文件',
'size' => '大小',
'modified' => '最后修改日期',
'total size' => '占用总空间',
'total files' => '总文件数',
'total folders' => '总目录数',
'search' => '搜索',
'files' => '文件',
'folders' => '目录',
'both' => '两者都有',
'search results' => '搜索结果',
'no results' => '没有找到你要的',
'end of results' => '搜索结束',
'found' => '寻找');

?>