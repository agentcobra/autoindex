<?php

/*
fi.php
Suomi - Finnish
Translation by Daniel Schildt (autiomaa.org)
*/

$words = array(
'index of' => 'Tiedostolistaus',
'parent directory' => 'Ylempi hakemisto',
'file' => 'Tiedosto',
'size' => 'Koko',
'modified' => 'Muokattu',
'total size' => 'Koko yhteens&auml;',
'total files' => 'Tiedostoja yhteens&auml;',
'total folders' => 'Hakemistoja yhteens&auml;',
'search' => 'Hae',
'files' => 'Tiedostoa',
'folders' => 'Hakemistoa',
'both' => 'Kumpaakin',
'search results' => 'Hakutulokset',
'no results' => 'EI TULOKSIA L&Ouml;YDETTY',
'end of results' => 'Haun loppu',
'found' => 'l&ouml;ydetty');

?>