<?php

/*
en.php
English
*/

$words = array(
'index of' => 'Index of',
'parent directory' => 'Parent Directory',
'file' => 'File',
'size' => 'Size',
'modified' => 'Modified',
'total size' => 'Total size',
'total files' => 'Total files',
'total folders' => 'Total folders',
'search' => 'Search',
'files' => 'Files',
'folders' => 'Folders',
'both' => 'Both',
'search results' => 'Search results',
'no results' => 'NO RESULTS FOUND',
'end of results' => 'End of search',
'found' => 'found');

?>