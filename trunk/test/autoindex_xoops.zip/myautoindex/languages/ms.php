<?php

/*
ms.php
Melayu - Malay
Translation by Haji Keropok
*/

$words = array(
'index of' => 'Indeks utk',
'parent directory' => 'Direktori Utama',
'file' => 'Fail',
'size' => 'Saiz',
'modified' => 'Diubahsuai',
'total size' => 'Jumlah saiz',
'total files' => 'Jumlah fail',
'total folders' => 'Jumlah folders',
'search' => 'Carian',
'files' => 'Fail',
'folders' => 'Folders',
'both' => 'Both',
'search results' => 'Keputusan carian',
'no results' => 'TIADA CARIAN DIJUMPAI',
'end of results' => 'Carian terakhir',
'found' => 'jumpa');

?>