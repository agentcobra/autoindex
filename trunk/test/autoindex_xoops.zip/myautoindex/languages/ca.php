<?php

/*
ca.php
Catal� - Catalan
Translation by David Gimeno i Ayuso (info@sima-pc.com)
*/

$words = array(
'index of' => '&Iacute;ndex de',
'parent directory' => 'Directori anterior',
'file' => 'Fitxer',
'size' => 'Tamany',
'modified' => 'Modificat',
'total size' => 'Tamany total',
'total files' => 'Total fitxers',
'total folders' => 'Total carpetes',
'search' => 'Cercar',
'files' => 'Fitxers',
'folders' => 'Carpetes',
'both' => 'Ambd&oacute;s',
'search results' => 'Resultats cerca',
'no results' => 'NO SE N\'HA TROBAT CAP',
'end of results' => 'Final de cerca',
'found' => 'trobat');

?>