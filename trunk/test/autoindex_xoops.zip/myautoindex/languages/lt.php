<?php

/*
lt.php
Lietuvi� - Lithuanian
Translation by Darius Kasperavi�ius (verslo@centras.lt)
*/

$words = array(
'index of' => 'Turinys:',
'parent directory' => 'Auk&eth;tesnis katalogas',
'file' => 'Byla',
'size' => 'Dydis',
'modified' => 'Taisyta',
'total size' => 'Dydis i&eth; viso',
'total files' => 'I&eth; viso byl&oslash;',
'total folders' => 'I&eth; viso katalog&oslash;',
'search' => 'Paie&eth;ka',
'files' => 'Bylos',
'folders' => 'Katalogai',
'both' => 'Abu',
'search results' => 'Paie&eth;kos rezultatai',
'no results' => 'rezultat&oslash; nreasta',
'end of results' => 'Paie&eth;kos pabaiga',
'found' => 'rasta');

?>