<?php
$modversion['name'] = "my autoindex";  
$modversion['version'] = 1; 			      
$modversion['description'] = "autoindex para xoops"; 
$modversion['credits'] = "";			     
$modversion['help'] = "";		      
$modversion['license'] = "GPL see LICENSE";	
$modversion['official'] = 0;			      
$modversion['image'] = "images/slogo.png";	
$modversion['dirname'] = "myautoindex";		
$modversion['hasAdmin'] = 0;
$modversion['hasMain'] = 1; 	
$modversion['hasSearch'] = 0;

?>