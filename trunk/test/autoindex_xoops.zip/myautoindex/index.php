<?php
/***************************************************************************
AutoIndex PHP Script as a module for XOOPS
---------------------------------------------------------------------------
Based on the Autoindex PHP Script by Justin Hagstrom, Modified for PHP-Nuke
by Kevin Sonnemann.
---------------------------------------------------------------------------
Modified for XOOPS by Javier Guajardo.
javierguajardo@gmail.com

Tested on Xoops 2.0.10

2005/05/20
**************************************************************************/
include("../../mainfile.php");
include(XOOPS_ROOT_PATH."/header.php");


/***************************************************************************
                  AutoIndex PHP Script, by Justin Hagstrom
                             -------------------

   filename             : index.php
   version              : 1.4.5
   date                 : May 11, 2004

   copyright            : Copyright (C) 2002-2004 Justin Hagstrom
   license              : GNU General Public License (GPL)

   website & forum      : http://autoindex.sourceforge.net
   e-mail               : JustinHagstrom [at] yahoo [dot] com



   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

 ***************************************************************************/

//if (!eregi("modules.php", $_SERVER['PHP_SELF'])) {
//    die ("You can't access this file directly...");
//}
 /*    OPTIONAL SETTINGS    */
$stored_config = 'AutoIndex.conf.php';
$config_generator = 'config.php';
/*  END OPTIONAL SETTINGS  */

define('VERSION', '1.4.5');
function get_microtime()
{
	list($usec, $sec) = explode(' ', microtime());
	return ((float)$usec + (float)$sec);
}
$start_time = get_microtime();



//some basic compatibility for PHP 4.0.x
if (!isset($_GET)) { $_GET = &$HTTP_GET_VARS; }
if (!isset($_POST)) { $_POST = &$HTTP_POST_VARS; }
if (!isset($_SESSION)) { $_SESSION = &$HTTP_SESSION_VARS; }
if (!isset($_SERVER)) { $_SERVER = &$HTTP_SERVER_VARS; }
if (!isset($_COOKIE)) { $_COOKIE = &$HTTP_COOKIE_VARS; }
if (!isset($_FILES)) { $_FILES = &$HTTP_POST_FILES; }

if (get_magic_quotes_gpc())
//remove any slashes added by the "magic quotes" setting
{
	foreach ($_GET as $key => $element)
	{
		$_GET[$key] = stripslashes($element);
	}
	foreach ($_POST as $key => $element)
	{
		$_POST[$key] = stripslashes($element);
	}
}

if (ini_get('zlib.output_compression') == '1')
//compensate for compressed output set in php.ini
{
	header('Content-Encoding: gzip');
}

//now we need to include either the stored settings, or the config generator
if (is_file($stored_config))
{
	if (!@include($stored_config))
	{
		die("<p>Error including file <i>$stored_config</i></p>");
	}
}
else if (is_file($config_generator))
{
	define('CONFIG', true);
	if (!@include($config_generator))
	{
		die("<p>Error including file <i>$config_generator</i></p>");
	}
	die();
}
else
{
	die("<p>Error: Neither <i>$config_generator</i> nor <i>$stored_config</i> could be found.</p>");
}

$posix = !eregi('win', PHP_OS); //check server OS
$this_file = (($index == '') ? $_SERVER['PHP_SELF'] : $index);
$this_file .= ((strpos($this_file, '?') !== false) ? '&' : "?name=$module_name&");
$referrer = (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'N/A');

//make sure all the variables are set correctly from the stored settings
$config_vars = array('base_dir', 'icon_path', 'stylesheet', 'use_login_system',
'allow_uploads', 'must_login_to_download', 'user_list', 'allow_file_overwrites',
'log_file', 'dont_log_these_ips', 'download_count', 'links_file', 'lang',
'sub_folder_access', 'index', 'hidden_files', 'show_only_these_files',
'force_download', 'bandwidth_limit', 'anti_leech', 'enable_searching',
'show_dir_size', 'folder_expansion', 'show_folder_count', 'banned_list',
'md5_show', 'header', 'footer', 'header_per_folder', 'footer_per_folder',
'description_file', 'thumbnail_height', 'path_to_language_files', 'days_new',
'select_language', 'show_type_column', 'show_size_column', 'show_date_column');
foreach ($config_vars as $this_var)
{
	if (!isset($$this_var))
	{
		die("<p>Error: AutoIndex is not configured properly.
		<br />The variable <b>$this_var</b> is not set.</p>
		<p>Delete <i>$stored_config</i> and then run <i>$config_generator</i>.</p>");
	}
}

//find the language the script should be displayed in
if ($select_language && isset($_GET['lang']) && eregi('^[a-z]{2}(_[a-z]{2})?$', $_GET['lang'])
	&& is_file($path_to_language_files.$_GET['lang'].'.php'))
{
	$_SESSION['lang'] = $_GET['lang'];
}
else if (!isset($_SESSION['lang']))
{
	$_SESSION['lang'] = $lang;
}
@include($path_to_language_files.$_SESSION['lang'].'.php');

if (!isset($words))
{
	die('<p>Error: You need to include a language.php file that has the variable $words.
	<br />Check the $lang and $path_to_language_files variables.</p>');
}

function translate_uri($uri)
//rawurlencodes $uri, but not any slashes
{
	$uri = rawurlencode(str_replace('\\', '/', $uri));
	return str_replace(rawurlencode('/'), '/', $uri);
}

function get_basename($fn)
//returns everything after the slash, or the original string if there is no slash
{
	$fn = str_replace('\\', '/', $fn);
	$pos = strrpos($fn, '/');
	if ($pos === false)
	{
		return $fn;
	}
	return substr($fn, $pos+1);
}

function match($a, $b)
//determines if two strings match (includes wildcards, and is case-sensitive based on OS)
{
	global $posix;
	$replace = array(
		'.' => '\.',
		'^' => '\^',
		'$' => '\$',
		'[' => '\[',
		']' => '\]',
		'(' => '\(',
		')' => '\)',
		'{' => '\{',
		'}' => '\}',
		'|' => '\|',
		'\\' => '/',
		'*' => '[^/]*',
		'+' => '[^/]+',
		'?' => '[^/]?');
	$a = get_basename($a);
	$b = '^' . strtr(get_basename($b), $replace) . '$';
	return ($posix ? ereg($b, $a) : eregi($b, $a));
}

function match_in_array($string, &$array)
//returns true if match() returns true for anything in the array
{
	for ($i=0; $i<count($array); $i++)
	{
		if ($array[$i] != '' && match($string, $array[$i]))
		{
			return true;
		}
	}
	return false;
}

function is_hidden($fn)
//looks at $hidden_files and $show_only_these_files to see if $fn is hidden
{
	if ($fn == '')
	{
		return true;
	}
	global $hidden_files, $show_only_these_files;
	if (count($show_only_these_files))
	{
		return (!match_in_array($fn, $show_only_these_files));
	}
	if (!count($hidden_files))
	{
		return false;
	}
	return match_in_array($fn, $hidden_files);
}

function eval_dir($d)
//check $d for "bad" things, and deal with ".."
{
	$d = str_replace('\\', '/', $d);
	if ($d == '' || $d == '/')
	{
		return '';
	}
	$dirs = explode('/', $d);
	for ($i=0; $i<count($dirs); $i++)
	{
		if ($dirs[$i] == '' || $dirs[$i] == '.' || is_hidden($dirs[$i]))
		{
			array_splice($dirs, $i, 1);
			$i = -1;
		}
		else if (ereg('^[\.]{2}', $dirs[$i])) //if it starts with two dots
		{
			array_splice($dirs, $i-1, 2);
			$i = -1;
		}
	}
	$new_dir = implode('/', $dirs);
	if ($d[0] == '/' && ereg('^[^/]', $new_dir))
	{
		$new_dir = '/'.$new_dir;
	}
	if ($d[strlen($d)-1] == '/' && ereg('[^/]$', $new_dir))
	{
		$new_dir .= '/';
	}
	return $new_dir;
}

//get the user defined variables that are in the URL
$subdir = (isset($_GET['dir']) ? eval_dir(rawurldecode($_GET['dir'])) : '');
$file_dl = (isset($_GET['doc']) ? eval_dir(rawurldecode($_GET['doc'])) : '');
$search = (isset($_GET['search']) ? $_GET['search'] : '');
$search_mode = (isset($_GET['searchMode']) ? $_GET['searchMode'] : '');

if (!is_dir($base_dir))
{
	die('<p>Error: <i>'.htmlentities($base_dir).'</i> is not a valid directory.<br />Check the $base_dir variable.</p>');
}

if (!$sub_folder_access || $subdir == '/')
{
	$subdir = '';
}
else if (ereg('[^/\\]$', $subdir))
{
	$subdir .= '/'; //add a slash to the end if there isn't one
}

$dir = $base_dir.$subdir;

//this will be displayed before any HTML output
/*
$html_heading = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';

if ($index == '')
{
	$html_heading .= "\n".'<html xmlns="http://www.w3.org/1999/xhtml"><head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
}
if ($stylesheet != '')
{
	$html_heading .= "\n<link rel=\"stylesheet\" href=\"$stylesheet\" type=\"text/css\" />\n";
}
if ($index == '')
{
	$html_heading .= "\n<title>".$words['index of'].' '.htmlentities($dir)
		."</title>\n\n</head><body class='autoindex_body'>\n\n";
}
*/

$html_heading = '';

if ($stylesheet != '')
{
	$html_heading .= "\n<link rel=\"stylesheet\" href=\"$stylesheet\" type=\"text/css\" />\n";
}
if ($index == '')
{
	$html_heading .= "\n<title>Documents</title>\n\n</head>";
		//."<body class='autoindex_body'>\n\n";
}

function show_header()
{
	global $header, $header_per_folder, $dir;
	if ($header != '')
	{
		if ($header_per_folder)
		{
			$header = $dir.$header;
		}
		if (is_readable($header))
		{
			include($header);
		}
	}
}

function show_footer()
{
	global $footer, $footer_per_folder, $dir;
	if ($footer != '')
	{
		if ($footer_per_folder)
		{
			$footer = $dir.$footer;
		}
		if (is_readable($footer))
		{
			include($footer);
		}
	}
}

function show_login_box()
{
	global $this_file, $subdir;
	$sd = translate_uri($subdir);
	echo '<p><table border="0" cellpadding="8" cellspacing="0">
	<tr class="paragraph"><td class="default_td">Login:<br />'
	."\n<form method='post' action='{$this_file}dir=$sd'>
	<p>Username: <input type='text' name='user' />
	<br />Password: <input type='password' name='pass' /></p>
	<p><input class='button' type='submit' value='Login' /></p>
	</form></td></tr></table></p>";
}

function show_search_box()
{
	global $index, $search, $words, $search_mode, $this_file, $subdir;
	echo '<p><table border="0" cellpadding="8" cellspacing="0">
	<tr class="paragraph"><td class="default_td">'
	.$words['search'].":<br /><form method='get' action='$this_file'>";
	echo "<input type=\"hidden\" name=\"name\" value=\"Documents\">";
	echo "<p><input type='text' name='search' value='$search' />\n";
	if ($index != '' && strpos($index, '?') !== false)
	{
		$id_temp = explode('=', $index, 2);
		$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
		echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
	}
	
	echo "\n<input type='hidden' name='dir' value='".translate_uri($subdir)
		."' /><br /><select name='searchMode'>\n";
	$search_modes = array($words['files'] => 'f', $words['folders'] => 'd', $words['both'] => 'fd');
	foreach ($search_modes as $key => $element)
	{
		$sel = (($search_mode == $element) ? ' selected' : '');
		echo "\t<option$sel value='$element'>$key</option>\n";
	}
	echo "</select><input type='submit' value='".$words['search']
		."' class='button' /></p></form>"
		.'</td></tr></table></p>';
}

function check_login($user, $pass)
{
	global $user_list, $html_heading;
	($users = @file($user_list)) or die("$html_heading<p>Could not open file <b>$user_list</b></p>");
	for ($i=0; $i<count($users); $i++)
	{
		if ((strcasecmp(substr(rtrim($users[$i]), 33), $user) == 0)
			&& (strcasecmp(substr(rtrim($users[$i]), 0, 32), $pass) == 0))
		{
			return true;
		}
	}
	return false;
}

function logged_in()
{
	return (isset($_SESSION['user'], $_SESSION['pass']) &&
		check_login($_SESSION['user'], $_SESSION['pass']));
}

function is_user_admin($user)
{
	global $user_list, $html_heading;
	($users = @file($user_list)) or die("$html_heading<p>Could not open file <b>$user_list</b></p>");
	$user = strtolower($user);
	for ($i=0; $i<count($users); $i++)
	{
		if (strtolower(substr(rtrim($users[$i]), 33)) == $user)
		{
			return (substr($users[$i], 32, 1) == '1');
		}
	}
	return false;
}
/*  FUNCTION WITH SAME NAME WAS ALREADY IN USE WITH PHPNUKE
function is_admin()
{
	return is_user_admin($_SESSION['user']);
}
*/
function is_username($user)
{
	global $user_list, $html_heading;
	($users = @file($user_list)) or die("$html_heading<p>Could not open file <b>$user_list</b></p>");
	$user = strtolower($user);
	for ($i=0; $i<count($users); $i++)
	{
		if (strtolower(substr(rtrim($users[$i]), 33)) == $user)
		{
			return true;
		}
	}
	return false;
}

function num_admins()
//returns the number of accounts with admin rights
{
	global $user_list, $html_heading;
	$num = 0;
	$users = @file($user_list) or die("$html_heading<p>Could not open file <b>$user_list</b></p>");
	for ($i=0; $i<count($users); $i++)
	{
		if (substr($users[$i], 32, 1) == '1')
		{
			$num++;
		}
	}
	return $num;
}

function get_filesize($size)
//give a size in bytes, and this will return the appropriate measurement format
{
	$size = max(0, $size);
	static $u = array('&nbsp;B', 'KB', 'MB', 'GB');
	for ($i=0; $size >= 1024 && $i < 4; $i++)
	{
		$size /= 1024;
	}
	return number_format($size, 1).' '.$u[$i];
}

function ext($fn)
//return the lowercase file extension of $fn, not including the leading dot
{
	$fn = get_basename($fn);
	return (strpos($fn, '.') ? strtolower(substr(strrchr($fn, '.'), 1)) : '');
}

function get_all_files($path)
//returns an array of every file in $path, including folders (except ./ and ../)
{
	$list = array();
	if (($hndl = @opendir($path)) === false)
	{
		return $list;
	}
	while (($file=readdir($hndl)) !== false)
	{
		if ($file != '.' && $file != '..')
		{
			$list[] = $file;
		}
	}
	closedir($hndl);
	return $list;
}

function get_file_list($path)
//returns a sorted array of filenames. Filters out "bad" files
{
	global $sub_folder_access, $links_file;
	$f = $d = array();
	$list = get_all_files($path);
	$num = count($list);
	for ($i=0; $i<$num; $i++)
	{
		if (!is_hidden($list[$i]))
		{
			if ($sub_folder_access && @is_dir("$path/".$list[$i]))
			{
				$d[] = $list[$i];
			}
			else if (@is_file("$path/".$list[$i]))
			{
				$f[] = $list[$i];
			}
		}
	}
	if ($links_file != '' && ($links = @file($path.$links_file)))
	{
		for ($i=0; $i<count($links); $i++)
		{
			$p = strpos($links[$i], '|');
			$f[] = (($p === false) ? rtrim($links[$i]).'|' : substr(rtrim($links[$i]), 0, $p).'|');
		}
	}
	natcasesort($d);
	natcasesort($f);
	return array_merge($d, $f);
}

function dir_size($dir)
//returns the total size of a directory (recursive) in bytes
{
	$totalsize = 0;
	$list = get_file_list($dir);
	$d = count($list);
	for ($i=0; $i<$d; $i++)
	{
		$totalsize += (is_dir("$dir/".$list[$i]) ? dir_size("$dir/".$list[$i]) : filesize("$dir/".$list[$i]));
	}
	return $totalsize;
}

function match_filename($filename, $string)
{
	if (preg_match_all("/(?<=\")[^\"]+(?=\")|[^ \"]+/", $string, $matches))
	{
		foreach ($matches[0] as $w)
		{
			if (ereg('[^/\.]+', $w) && stristr($filename, $w))
			{
				return true;
			}
		}
	}
	return false;
}

function search_dir($sdir, $string)
//returns files/folders (recursive) in $sdir that contain $string
{
	global $search_mode;
	//searchMode: d=folders, f=files, fd=both

	$found = array();
	$list = get_file_list($sdir);
	$d = count($list);
	for ($i=0; $i<$d; $i++)
	{
		$full_name = $sdir.$list[$i];
		if (stristr($search_mode, 'f') && (is_file($full_name) || ereg('\|$', $list[$i])) && match_filename($list[$i], $string))
		{
			$found[] = $full_name;
		}
		else if (is_dir($full_name))
		{
			if (stristr($search_mode, 'd') && match_filename($list[$i], $string))
			{
				$found[] = $full_name;
			}
			$found = array_merge($found, search_dir($full_name.'/', $string));
		}
	}
	return $found;
}

function add_num_to_array($num, &$array)
{
	isset($array[$num]) ? $array[$num]++ : $array[$num] = 1;
}

function mkdir_recursive($path)
{
	if (is_dir($path))
	{
		return true;
	}
	if (!mkdir_recursive(dirname($path)))
	{
		return false;
	}
	return @mkdir($path, 0755);
}

function num_files($dir)
//returns the number of files in $dir (recursive)
{
	$count = 0;
	$list = get_file_list($dir);
	$d = count($list);
	for ($i=0; $i<$d; $i++)
	{
		$count += (is_dir("$dir/".$list[$i]) ? num_files("$dir/".$list[$i]) : 1);
	}
	return $count;
}

function redirect($site)
{
	header("Location: $site");
	die("<p>Continue here: <a href=\"$site\">$site</a></p>");
}

function icon($ext)
//find the appropriate icon depending on the extension (returns a link to the image file)
{
	global $icon_path;
	if ($icon_path == '')
	{
		return '';
	}
	if ($ext == '')
	{
		$icon = 'generic';
	}
	else
	{
		$icon = 'unknown';
		static $icon_types = array(
		'binary' => array('exe', 'bin', 'msi'),
		'binhex' => array('hqx'),
		'cd' => array('cue', 'mds', 'iso', 'nrg', 'mdf', 'ccd', 'bwt', 'cdi', 'img'),
		'dll' => array('dll', '386', 'db', 'ocx', 'sdb', 'vxd'),
		'tar' => array('tar'),
		'doc' => array('doc', 'rtf', 'wri', 'dif', 'cwk', 'ans', 'wps', 'wpd', 'wk4',
			'sxw', 'mcw', 'sdw', 'vor', 'chm'),
		'xls' => array('xla', 'xls', 'xlt', 'xlw', 'csv', 'dbf', 'prn', 'sxc'),
		'ppt' => array('ppt', 'pps', 'pot', 'ppa', 'emf', 'shw', 'sxi'),
		'ps' => array('ps'),
		'pdf' => array('pdf', 'edn', 'pdx', 'pdp'),
		'java' => array('jar', 'java', 'jtk', 'class'),
		'js' => array('js', 'jse', 'vbs', 'ebs', 'wsc', 'wsf', 'wsh'),
		'compressed' => array('zip', 'z', 'tgz', 'gz', 'rar', 'bz2', 'tbz', '7z', 'ace',
			'lzh', 'xxe', 'sit', 'sea', 'arc', 'taz', 'tbz2', 'deb', 'rpm', 'cab',
			'zoo', 'arj', 'lha', 'a'),
		'image' => array('jpg', 'png', 'bmp', 'gif', 'tif', 'tga', 'jpeg', 'tiff',
			'psd', 'jpc', 'jp2', 'jpx', 'swc', 'jfif', 'art', 'ico', 'jpe', 'jif',
			'xcf', 'wpg', 'sxd'),
		'movie' => array('mpg', 'avi', 'divx', 'mpeg', 'ram', 'wmv', 'mpe', 'asf',
			'mkv', 'asx', 'ogm'),
		'mov' => array('mov', 'qt', 'mac', 'mpg4', 'pct', 'pic', 'pict', 'pnt', 'pntg',
			'qti', 'qtif', 'qtl', 'qts', 'qtx'),
		'sound' => array('mp3', 'mp2', 'ogg', 'wav', 'mpc', 'flac', 'ape', 'aac', 'mp4',
			'aif', 'aiff', 'au', 'mid', 'midi', 'vqf', 'mod', 'wma', 'voc', 'mp+',
			'mpp', 'bonk', 'ofr', 'shn', 'lqt', 'mpga', 'ra', 'pac', 'wv', 'mka',
			'mp1', 'spc', 'rmjb', 'rm', 'm4a', 'wave', 'pcm', 'la'),
		'uu' => array('uue', 'uu', 'uud'),
		'text' => array('txt', 'md5', 'sfv', 'c', 'cpp', 'h', 'm3u', 'cc', 'cp'),
		'comp' => array('nfo', 'ini', 'inf', 'cfg', 'log', 'conf', 'reg'),
		'web' => array('html', 'htm', 'asp', 'css', 'shtml', 'pl', 'perl', 'swf', 'cgi',
			'mht', 'mhtml', 'xml', 'rss', 'dtd', 'jsp', 'lnk', 'com', 'org', 'net'),
		'php' => array('php', 'phps', 'php3', 'php4', 'phtml'),
		'key' => array('pgp', 'asc', 'ppk', 'key'));
		foreach ($icon_types as $png_name => $exts)
		{
			if (in_array($ext, $exts))
			{
				$icon = $png_name;
				break;
			}
		}
	}
	return "<img border=\"0\" alt=\"[$ext]\" height=\"16\" width=\"16\" src=\"$icon_path/$icon.png\" /> ";
}

function display_thumbnail($file, $thumbnail_height)
{
	global $html_heading;
	if (!is_file($file))
	{
		die("$html_heading<p>File not found: <i>".htmlentities($file).'</i></p>');
	}
	switch (ext($file))
	{
		case 'gif':
			$src = @imagecreatefromgif($file);
			break;
		case 'jpg':
		case 'jpeg':
			$src = @imagecreatefromjpeg($file);
			break;
		case 'png':
			$src = @imagecreatefrompng($file);
			break;
		default:
			die("$html_heading<p>Unsupported file extension.</p>");
	}
	if ($src === false)
	{
		die("$html_heading<p>Unsupported image type.</p>");
	}
	
	header('Content-Type: image/jpeg');
	header('Cache-Control: public, max-age=3600, must-revalidate');
	header('Expires: '.gmdate('D, d M Y H:i:s', time()+3600).' GMT');
	$src_height = imagesy($src);
	if ($src_height <= $thumbnail_height)
	{
		imagejpeg($src, '', 95);
	}
	else
	{
		$src_width = imagesx($src);
		$thumb_width = $thumbnail_height * ($src_width / $src_height);
		$thumb = imagecreatetruecolor($thumb_width, $thumbnail_height);
		imagecopyresampled($thumb, $src, 0, 0, 0, 0, $thumb_width,
			$thumbnail_height, $src_width, $src_height);
		imagejpeg($thumb);
		imagedestroy($thumb);
	}
	imagedestroy($src);
	die();
}

function edit_description($fn, &$desc)
//edits a file's description
{
	global $description_file, $html_heading;
	if ($description_file == '')
	{
		return;
	}
	$wrote = false;
	$l = @file($description_file) or $l = array();
	$h = @fopen($description_file, 'wb') or die("$html_heading<p>Cannot open description file for writing.</p>");
	$count_num = count($l);
	for ($i=0; $i<$count_num; $i++)
	{
		$items = explode('|', rtrim($l[$i]), 2);
		if (count($items) == 2 && $fn == $items[0])
		{
			fwrite($h, "$fn|$desc\n");
			$wrote = true;
		}
		else
		{
			fwrite($h, $l[$i]);
		}
	}
	if (!$wrote && $desc != '')
	{
		fwrite($h, "$fn|$desc\n");
	}
	fclose($h);
}

function add_to_file($item, $outfile)
{
	global $html_heading;
	$counted = false;
	if ($l = @file($outfile))
	{
		$count_num = count($l);
		for ($i=0; $i<$count_num; $i++)
		{
			$thisc = rtrim($l[$i]);
			if ($item == substr($thisc, 0, strpos($thisc, '|')))
			{
				$counted = true;
				break;
			}
		}
	}
	if ($counted)
	{
		$w = @fopen($outfile, 'wb') or die("$html_heading<p>Could not open <i>$outfile</i> file for writing.</p>");
		for ($i=0; $i<$count_num; $i++)
		{
			$items = explode('|', rtrim($l[$i]), 2);
			if (count($items) == 2 && $items[0] == $item)
			{
				$nc = $items[1] + 1;
				fwrite($w, "$item|$nc\n");
			}
			else
			{
				fwrite($w, $l[$i]);
			}
		}
	}
	else
	{
		$w = @fopen($outfile, 'ab') or die("$html_heading<p>Could not open <i>$outfile</i> file for writing.</p>");
		fwrite($w, "$item|1\n");
	}
	fclose($w);
}

function get_stored_info($item, $filename)
{
	if ($contents = @file($filename))
	{
		$count_num = count($contents);
		for ($i=0; $i<$count_num; $i++)
		{
			$items = explode('|', rtrim($contents[$i]), 2);
			if (count($items) == 2 && $item == $items[0])
			{
				return $items[1];
			}
		}
	}
	return '';
}

function table_heading($title, $sortMode, $tooltip)
{
	global $this_file, $subdir;
	echo "\n<th class='default_th'><a title=\"$tooltip\" href=\""
	.$this_file.'dir='.translate_uri($subdir).'&amp;sort='
	.(($_SESSION['sort'] == 'a' && $_SESSION['sortMode'] == $sortMode) ? 'd' : 'a')
	.'&amp;sortMode='.$sortMode.'"><b><font color="#FFFFFF">'
	.$title.'</font></b></a></th>';
}

function client_ip()
{
	if (isset($_SERVER['HTTP_CLIENT_IP']))
	{
		return $_SERVER['HTTP_CLIENT_IP'];
	}
	if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
	{
		return $_SERVER['HTTP_X_FORWARDED_FOR'];
	}
	if (isset($_SERVER['REMOTE_ADDR']))
	{
		return $_SERVER['REMOTE_ADDR'];
	}
	return 'N/A';
}

//find the user's IP address and hostname
if (!isset($_SESSION['ip'], $_SESSION['host']))
{
	$_SESSION['ip'] = client_ip();
	$_SESSION['host'] = @gethostbyaddr($_SESSION['ip'])
		or $_SESSION['host'] = 'N/A';
}
$ip = $_SESSION['ip'];
$host = $_SESSION['host'];

if ($banned_list != '' && ($b_list = @file($banned_list)))
{
	for ($i=0; $i<count($b_list); $i++)
	{
		$b_list[$i] = rtrim($b_list[$i]);
	}
	if (match_in_array($ip, $b_list) || match_in_array($host, $b_list))
	{
		echo $html_heading;
		show_header();
		echo '<p>Sorry, the administrator has blocked your IP address or hostname.</p>';
		show_footer();
		die();
	}
}

function ok_to_log()
//returns true if the ip or hostname is not in $dont_log_these_ips
{
	global $ip, $host, $dont_log_these_ips;
	return (!(match_in_array($ip, $dont_log_these_ips) ||
		($host != 'N/A' && match_in_array($host, $dont_log_these_ips))));
}

if ($use_login_system && isset($_POST['user'], $_POST['pass'])
	&& $_POST['user'] != '' && $_POST['pass'] != '')
//check login
{
	if (check_login($_POST['user'], md5($_POST['pass'])))
	{
		if ($log_file != '' && ok_to_log())
		{
			if ($write = @fopen($log_file, 'ab'))
			{
				fwrite($write, date('Y-M-d')."\t".date('H:i:s')
					."\t$ip\t$host\t$referrer\t$dir\tSuccessful Login (username: "
					.$_POST['user'].")\n");
				fclose($write);
			}
		}
		$_SESSION['user'] = $_POST['user'];
		$_SESSION['pass'] = md5($_POST['pass']);
		unset($_POST['pass'], $_POST['user']);
		redirect($this_file.'dir='.translate_uri($subdir));
	}
	else
	{
		echo '<h3>Invalid Login.</h3>';
		if ($log_file != '' && ok_to_log())
		{
			if ($write = @fopen($log_file, 'ab'))
			{
				fwrite($write, date('Y-M-d')."\t".date('H:i:s')
					."\t$ip\t$host\t$referrer\t$dir\tInvalid Login (username: "
					.$_POST['user'].")\n");
				fclose($write);
			}
		}
		sleep(1); //"freeze" the script for a second to prevent brute force attacks
	}
}

if ($use_login_system && $must_login_to_download && !logged_in())
//must login to download
{
	echo $html_heading;
	show_header();
	echo '<p>You must login to download and view files.</p>';
	show_login_box();
	show_footer();
	die();
}

if ($md5_show && isset($_GET['md5']))
{
	$file = $dir.eval_dir(rawurldecode($_GET['md5']));
	if (!is_file($file))
	{
		die($html_heading.'<p>Error: file does not exist.</p>');
	}
	$size = max(0, filesize($file));
	if (!$size || $size/1048576 > $md5_show)
	{
		die($html_heading.'<p><b>Error</b>: empty file, or file too big to find the md5sum of (according to the $md5_show variable).</p>');
	}
	die(md5_file($file));
}

if ($thumbnail_height > 0 && isset($_GET['thumbnail']) && $_GET['thumbnail'] != '')
{
	$file = $dir.eval_dir(rawurldecode($_GET['thumbnail']));
	display_thumbnail($file, $thumbnail_height);
}

if (isset($_GET['sort']))
{
	$_SESSION['sort'] = $_GET['sort'];
}
else if (!isset($_SESSION['sort']))
{
	//'a' is ascending, 'd' is descending
	$_SESSION['sort'] = 'a';
}

if (isset($_GET['sortMode']))
{
	$_SESSION['sortMode'] = $_GET['sortMode'];
}
else if (!isset($_SESSION['sortMode']))
{
	/*
	 * 'f' is filename
	 * 't' is filetype
	 * 'h' is downloads (hits)
	 * 's' is size
	 * 'm' is date (modified)
	 * 'd' is description
	 */
	$_SESSION['sortMode'] = 'f';
}

//size of the "chunks" that are read at a time from the file (when $force_download is on)
$speed = ($bandwidth_limit ? $bandwidth_limit : 4);

if ($folder_expansion)
{
	if (!isset($_SESSION['expanded']))
	{
		$_SESSION['expanded'] = array();
	}
	if (isset($_GET['expand']) && $_GET['expand'] != '')
	{
		$temp = $dir.eval_dir(rawurldecode($_GET['expand']));
		if (is_dir($temp) && !in_array($temp, $_SESSION['expanded']))
		{
			$_SESSION['expanded'][] = $temp;
		}
	}
	if (isset($_GET['collapse']) && $_GET['collapse'] != '')
	{
		$temp = $dir.eval_dir(rawurldecode($_GET['collapse']));
		if (in_array($temp, $_SESSION['expanded']))
		{
			array_splice($_SESSION['expanded'], array_search($temp, $_SESSION['expanded']), 1);
		}
	}
}

if ($allow_uploads && (!$use_login_system || logged_in()))
//upload a file
{
	if ($count_files = count($_FILES))
	{
		echo $html_heading;
		show_header();
		$uploaded_files = $errors = '';
		for ($i=0; $i<$count_files; $i++)
		{
			if ($_FILES[$i]['name'] != '')
			{
				$filename = get_basename($_FILES[$i]['name']);
				$filepath = $base_dir.eval_dir(rawurldecode($_POST['dir']));
				$fullpathname = realpath($filepath).'/'.$filename;
				if (is_hidden($filename))
				{
					$errors .= "<li>$filename [filename is listed as a hidden file]</li>";
				}
				else if (!$allow_file_overwrites && file_exists($fullpathname))
				{
					$errors .= "<li>$filename [file already exists]</li>";
				}
				else if (@move_uploaded_file($_FILES[$i]['tmp_name'], $fullpathname))
				{
					@chmod($fullpathname, 0644);
					$uploaded_files .= "<li>$filename</li>";
					if ($log_file != '' && ok_to_log())
					{
						if ($write = @fopen($log_file, 'ab'))
						{
							fwrite($write, date('Y-M-d')."\t".date('H:i:s')
								."\t$ip\t$host\t$referrer\t$dir\tFile uploaded: $filepath$filename\n");
							fclose($write);
						}
					}
				}
				else
				{
					$errors .= "<li>$filename</li>";
				}
			}
		}
		if ($errors == '')
		{
			$errors = '<br />[None]';
		}
		if ($uploaded_files == '')
		{
			$uploaded_files = '<br />[None]';
		}
		echo "<p><b>Uploaded files</b>: $uploaded_files</p><p><b>Failed files</b>: $errors</p>"
			.'<p><a class="default_a" href="'.$this_file.'dir='
			.$_POST['dir'].'">Continue.</a></p>';
		show_footer();
		die();
	}
	else if (isset($_POST['numUpload']))
	{
		echo $html_heading;
		show_header();
		echo "<p><table border='0' cellpadding='8' cellspacing='0'><tr class='paragraph'><td class='default_td'>
		<form enctype='multipart/form-data' action='$this_file' method='post'>
		<input type='hidden' name='dir' value='".$_POST['dir']."' />\n";
		$num = intval($_POST['numUpload']);
		for ($i=0; $i<$num; $i++)
		{
			$n = $i + 1;
			echo "\t\t{$words['file']} $n : <input name='$i' type='file' /><br />\n";
		}
		echo '<p><input class="button" type="submit" value="Upload Files" />
		</p></form></td></tr></table></p>';
		show_footer();
		die();
	}
}

if ($use_login_system && logged_in() && is_admin())
{
	$con = '<p><a class="default_a" href="'.$this_file.'dir='
		.translate_uri($subdir).'">Continue.</a></p>';

	if (isset($_GET['getcreate']))
	{
		echo $html_heading;
		show_header();
		echo "<p><table border='0' cellpadding='8' cellspacing='0'><tr class='paragraph'><td class='default_td'>
		Enter the name of the folder you would like to create:
		<form method='get' action='$this_file'>
		<input type='hidden' name='dir' value='".translate_uri($subdir)."' />";
		if ($index != '' && strpos($index, '?') !== false)
		{
			$id_temp = explode('=', $index, 2);
			$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
			echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
		}
		echo '<p><input type="text" name="create" /></p>
		<p><input class="button" type="submit" value="Create" /></p>
		</form></td></tr></table></p>';
		show_footer();
		die();
	}
	else if (isset($_GET['create']) && $_GET['create'] != '')
	{
		$p = $dir.eval_dir($_GET['create']);
		$msg = (is_dir($p) ? 'Folder already exists: ' : (mkdir_recursive($p) ? 'Folder successfully created: ' : 'Could not create folder: '));
		echo $html_heading;
		show_header();
		echo $msg.htmlentities($p).$con;
		show_footer();
		die();
	}
	else if ($description_file != '' && isset($_GET['descFile']) && $_GET['descFile'] != '')
	{
		if (isset($_GET['desc']))
		{
			$desc = trim(rawurldecode($_GET['desc']));
			$descFile = trim(rawurldecode($_GET['descFile']));
			edit_description($dir.$descFile, $desc);
		}
		else
		{
			$filen = rawurldecode($_GET['descFile']);
			echo $html_heading;
			show_header();
			echo "<p><table border='0' cellpadding='8' cellspacing='0'>
			<tr class='paragraph'><td class='default_td'>
			Enter the new description for the file <i>$filen</i>:
			<form method='get' action='$this_file'>
			<input type='hidden' name='dir' value='".translate_uri($subdir)."' />
			<input type='hidden' name='descFile' value='".translate_uri($filen).'\' />';
			if ($index != '' && strpos($index, '?') !== false)
			{
				$id_temp = explode('=', $index, 2);
				$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
				echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
			}
			echo '<p><input type="text" name="desc" size="50" value="'
			.get_stored_info($dir.$filen, $description_file).'" /></p>
			<p><input class="button" type="submit" value="Change" /></p>
			</form></td></tr></table></p>';
			show_footer();
			die();
		}
	}
	else if (isset($_GET['edit_links']))
	{
		echo $html_heading;
		show_header();
		echo '<p><table border="0" cellpadding="8" cellspacing="0">
			<tr class="paragraph"><td class="default_td">';
		if ($links_file == '')
		{
			echo '<p>The link system is not in use.<br />To turn it on, set the $links_file variable.</p>';
		}
		else if (isset($_GET['link'], $_GET['name']) && $_GET['link'] != '')
		{
			if ($handle = @fopen($dir.$links_file, 'ab'))
			{
				fwrite($handle, $_GET['link'].'|'.$_GET['name']."\n");
				fclose($handle);
				echo '<p>Link added.</p>';
			}
			else
			{
				echo '<p>Could not open links_file for writing.</p>';
			}
		}
		else if (isset($_GET['remove']))
		{
			if (($list = @file($dir.$links_file)) && ($handle = @fopen($dir.$links_file, 'wb')))
			{
				for ($i=0; $i<count($list); $i++)
				{
					if (rtrim($list[$i]) != rtrim($_GET['remove']))
					{
						fwrite($handle, $list[$i]);
					}
				}
				fclose($handle);
				echo '<p>Link removed.</p>';
			}
			else
			{
				echo '<p>Could not open links_file.</p>';
			}
		}
		else
		{
			echo '<h3>Add a new link:</h3><font size="1">for the directory <i>'.htmlentities($dir)
			."</i></font><form method='get' action='$this_file'>"
			.'<input type="hidden" name="dir" value="'.translate_uri($subdir)
			.'" /><p>URL: <input type="text" name="link" size="40" value="http://" />
			<br />Name: <input type="text" name="name" size="35" />
			<br /><font size="1">(Leave "name" blank for the URL itself to be shown.)</font></p>';
			if ($index != '' && strpos($index, '?') !== false)
			{
				$id_temp = explode('=', $index, 2);
				$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
				echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
			}
			echo '<input type="hidden" name="edit_links" value="true" />
			<p><input class="button" type="submit" value="Add" /></p></form></td></tr></table></p>'
			.'<p><table border="0" cellpadding="8" cellspacing="0"><tr class="paragraph"><td class="default_td">'
			.'<h3>Remove a link:</h3>'."<form method='get' action='$this_file'>";
			if ($index != '' && strpos($index, '?') !== false)
			{
				$id_temp = explode('=', $index, 2);
				$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
				echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
			}
			echo '<input type="hidden" name="dir" value="'.translate_uri($subdir).'" />'
			.'<input type="hidden" name="edit_links" value="true" />';
			$list = @file($dir.$links_file) or $list = array();
			echo '<select name="remove">';
			for ($i=0; $i<count($list); $i++)
			{
				echo '<option>'.$list[$i].'</option>';
			}
			echo '</select><p><input class="button" type="submit" value="Delete" /></form></p>';
		}
		echo '</p></td></tr></table>'.$con;
		show_footer();
		die();
	}
	else if (isset($_GET['copyFile'], $_GET['protocol']))
	{
		echo $html_heading;
		show_header();
		if ($_GET['copyFile'] == '')
		{
			echo '<p>Please go back and enter a file to copy.</p>'.$con;
			show_footer();
			die();
		}
		$remote = $_GET['protocol'].$_GET['copyFile'];
		$local = $dir.get_basename($remote);
		if (!$allow_file_overwrites && is_file($local))
		{
			echo "File already exists: <i>$local</i>$con";
			show_footer();
			die();
		}
		$r = @fopen($remote, 'rb') or die("<p>Cannot open remote file for reading: <i>$remote</i></p>$con");
		$l = @fopen($local, 'wb') or die("<p>Cannot open local file for writing: <i>$local</i></p>$con");
		while (true)
		{
			$temp = fread($r, 4096);
			if ($temp == '')
			{
				break;
			}
			fwrite($l, $temp);
		}
		fclose($l);
		fclose($r);
		echo "<p>Remote file <i>$remote</i> successfully copied to <i>$local</i></p>$con";
		show_footer();
		die();
	}
	else if (isset($_GET['copyURL']))
	{
		echo $html_heading;
		show_header();
		echo "<p><table border='0' cellpadding='8' cellspacing='0'>
		<tr class='paragraph'><td class='default_td'>
		Enter the name of the remote file you would like to copy:
		<form method='get' action='$this_file'>
		<input type='hidden' name='dir' value='".translate_uri($subdir)."' />";
		if ($index != '' && strpos($index, '?') !== false)
		{
			$id_temp = explode('=', $index, 2);
			$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
			echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
		}
		echo '<p><input type="radio" name="protocol" value="http://" checked />http://
		<br /><input type="radio" name="protocol" value="ftp://" />ftp://
		<input type="text" name="copyFile" /></p>
		<p><input class="button" type="submit" value="Copy" /></p>
		</form></td></tr></table></p>';
		show_footer();
		die();
	}
	else if (isset($_GET['rename']) && $_GET['rename'] != '')
	{
		echo $html_heading;
		show_header();
		echo '<p><table border="0" cellpadding="8" cellspacing="0">
		<tr class="paragraph"><td class="default_td">';
		$p = $dir.eval_dir(rawurldecode($_GET['rename']));
		if (isset($_GET['newName']) && $_GET['newName'] != '')
		{
			$new_name = $dir.eval_dir(rawurldecode($_GET['newName']));
			if ($p == $new_name)
			{
				$msg = 'The filename is unchanged for ';
			}
			else if (@rename($p, $new_name))
			{
				$msg = 'Rename successful for ';
				if ($download_count != '')
				{
					$l = @file($download_count) or $l = array();
					if ($h = @fopen($download_count, 'wb'))
					{
						for ($i=0; $i<count($l); $i++)
						{
							fwrite($h, ereg_replace("^$p", $new_name, $l[$i]));
						}
						fclose($h);
					}
				}
				if ($description_file != '')
				{
					$l = @file($description_file) or $l = array();
					if ($h = @fopen($description_file, 'wb'))
					{
						for ($i=0; $i<count($l); $i++)
						{
							fwrite($h, ereg_replace("^$p", $new_name, $l[$i]));
						}
						fclose($h);
					}
				}
			}
			else
			{
				$msg = 'Rename failed for ';
			}
			echo $msg.htmlentities($p).$con.'</td></tr></table></p>';
			show_footer();
			die();
		}
		echo '<p>Renaming <i>'.htmlentities($p)."</i></p><p>New Filename:
		<br /><font size='1'>(you can also move the file by specifying a path)</font>
		<form method='get' action='$this_file'>
		<input type='hidden' name='dir' value='".translate_uri($subdir)."' />
		<input type='hidden' name='rename' value='".translate_uri($_GET['rename']).'\' />';
		if ($index != '' && strpos($index, '?') !== false)
		{
			$id_temp = explode('=', $index, 2);
			$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
			echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
		}
		echo '<input type="text" name="newName" size="40" value="'.$_GET['rename'].'" /></p>
		<p><input class="button" type="submit" value="Rename" /></p></td></tr></table></p>';
		show_footer();
		die();
	}
	else if (isset($_GET['delete']) && $_GET['delete'] != '')
	{
		echo $html_heading;
		show_header();
		echo '<p><table border="0" cellpadding="8" cellspacing="0">
		<tr class="paragraph"><td class="default_td">';
		$_GET['delete'] = rawurldecode($_GET['delete']);
		$p = $dir.eval_dir($_GET['delete']);
		if (isset($_GET['sure'])) //delete the file
		{
			if (is_dir($p))
			{
				$msg = (@rmdir($p) ? 'Folder successfully deleted: '
					: 'Could not delete folder (make sure it is empty) ');
			}
			else if (is_file($p))
			{
				$msg = (@unlink($p) ? 'File successfully deleted: '
					: 'Could not delete file: ');
			}
			else
			{
				$msg = 'File or folder does not exist: ';
			}
		}
		else //ask user for confirmation
		{
			$msg = 'Are you sure you want to delete <i>';
			$con = '</i><p><a class="default_a" href="'.$this_file.'dir='
				.translate_uri($subdir).'&amp;delete='.translate_uri($_GET['delete'])
				.'&amp;sure=true">Yes, delete it.</a></p><p><a class="default_a" href="'
				.$this_file.'dir='.translate_uri($subdir).'">No, go back.</a></p>';
		}
		echo $msg.htmlentities($p).$con.'</td></tr></table></p>';
		show_footer();
		die();
	}
	else if (isset($_GET['config']))
	{
		if (is_file($config_generator))
		{
			define('CONFIG', true);
			if (!@include($config_generator))
			{
				die("$html_heading<p>Error including file <i>$config_generator</i></p>");
			}
			die();
		}
		else
		{
			die("$html_heading<p>File <i>$config_generator</i> not found.</p>");
		}
	}
	else if (isset($_GET['edit_ban']))
	{
		echo $html_heading;
		show_header();
		echo '<p><table border="0" cellpadding="8" cellspacing="0">
			<tr class="paragraph"><td class="default_td">';
		if ($banned_list == '')
		{
			echo '<p>The banning system is not in use.<br />To turn it on, set the $banned_list variable.</p>';
		}
		else if (isset($_GET['add_ban']))
		{
			if ($handle = @fopen($banned_list, 'ab'))
			{
				fwrite($handle, $_GET['add_ban']."\n");
				fclose($handle);
				echo '<p>Ban added.</p>';
			}
			else
			{
				echo '<p>Could not open ban_list file for writing.</p>';
			}
		}
		else if (isset($_GET['del_ban']))
		{
			$del_ban = rtrim($_GET['del_ban']);
			if (($list = @file($banned_list)) && ($handle = @fopen($banned_list, 'wb')))
			{
				for ($i=0; $i<count($list); $i++)
				{
					if (rtrim($list[$i]) != $del_ban)
					{
						fwrite($handle, $list[$i]);
					}
				}
				fclose($handle);
				echo '<p>Ban removed.</p>';
			}
			else
			{
				echo '<p>Could not open ban_list file.</p>';
			}
		}
		else
		{
			echo '<h3>Add a new ban:</h3>'
			."<form method='get' action='$this_file'>"
			.'IP address or hostname: <input type="text" name="add_ban" size="35" />
			<br /><font size="1">You can use wildcards if you want (*, ?, +)</font></p>';
			if ($index != '' && strpos($index, '?') !== false)
			{
				$id_temp = explode('=', $index, 2);
				$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
				echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
			}
			echo '<input type="hidden" name="edit_ban" value="true" />
			<p><input class="button" type="submit" value="Add" /></p></form></td></tr></table></p>'
			.'<p><table border="0" cellpadding="8" cellspacing="0"><tr class="paragraph"><td class="default_td">'
			.'<h3>Remove a ban:</h3>'."<form method='get' action='$this_file'>";
			if ($index != '' && strpos($index, '?') !== false)
			{
				$id_temp = explode('=', $index, 2);
				$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
				echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
			}
			echo '<input type="hidden" name="edit_ban" value="true" />';
			$list = @file($banned_list) or $list = array();
			echo '<select name="del_ban">';
			for ($i=0; $i<count($list); $i++)
			{
				echo '<option>'.$list[$i].'</option>';
			}
			echo '</select><p><input class="button" type="submit" value="Remove" /></form></p>';
		}
		echo '</p></td></tr></table>'.$con;
		show_footer();
		die();
	}
}

function get_change_color($num)
{
	if ($num > 0)
	{
		return '<font color="#00FF00">+';
	}
	if ($num < 0)
	{
		return '<font color="#FF0000">';
	}
	return '<font color="#FFFFFF">';
}

if ($use_login_system && isset($_GET['log']))
//logfile viewer
{
	echo $html_heading;
	show_header();
	if (!logged_in() || !is_admin())
	{
		echo '<p>You must be logged in as an admin to access this page.</p>';
	}
	else if ($log_file == '')
	{
		echo '<p>The logging system is not in use.
		<br />To turn it on, set the $log_file variable.</p>';
	}
	else if (isset($_GET['view']))
	{
		$log = @file($log_file) or die("Cannot open log file: <i>$log_file</i>");
		$count_log = count($log);
		$num = min(intval($_GET['view']), $count_log);
		echo "<p>Last $num log entries (of $count_log".')</p><table width="100%">
		<th class="default_th">&nbsp;</th><th class="default_th">Date</th>
		<th class="default_th">Time</th><th class="default_th">IP</th>
		<th class="default_th">Hostname</th><th class="default_th">Referrer</th>
		<th class="default_th">File/Folder Viewed</th><th class="default_th">Other</th>';
		for ($i=0; $i<$num; $i++)
		{
			$entries = explode("\t", rtrim($log[$count_log-$i-1]));
			$num_entries = count($entries);
			if ($num_entries > 5)
			{
				echo "\n<tr class=".(($i % 2) ? '"dark_row">' : '"light_row">')
					.'<td class="default_td"><b>'.($i+1).'</b></td>';
				for ($j=0; $j<$num_entries; $j++)
				{
					echo '<td class="default_td">'.(($j == 4 && $entries[4] != 'N/A') ?
						'<a class="default_a" href="'.$entries[$j].'">'.htmlentities($entries[$j]).'</a>' :
						htmlentities($entries[$j])).'</td>';
				}
				if ($num_entries == 6)
				{
					echo '<td class="default_td">&nbsp;</td>';
				}
				echo '</tr>';
			}
		}
		echo '</table>';
	}
	else if (isset($_GET['stats']))
	{
		if (!@include($path_to_language_files.'country_codes.php'))
		{
			die("<p>File not found: <i>{$path_to_language_files}country_codes.php</i></p>");
		}
		$extensions = $dates = $unique_hits = $countries = array();
		$total_hits = 0;
		$h = @fopen($log_file, 'rb') or die("<p>Cannot open log file: <i>$log_file</i></p>");
		while (!feof($h))
		{
			$entries = explode("\t", rtrim(fgets($h, 1024)));
			if (count($entries) > 5)
			{
				//find the number of unique visits
				if ($entries[5] == $base_dir)
				{
					$total_hits++;
					if (!in_array($entries[3], $unique_hits))
					{
						$unique_hits[] = htmlentities($entries[3]);
					}
	
					//find country codes by hostnames
					$cc = ext($entries[3]);
					if (eregi('^[a-z]+$', $cc))
					{
						add_num_to_array($cc, $countries);
					}
	
					//find the dates of the visits
					add_num_to_array($entries[0], $dates);
				}
	
				//find file extensions
				else if (($ext = ext($entries[5])) && ereg('^[^ \\/]+$', $ext))
				{
					add_num_to_array($ext, $extensions);
				}
			}
		}
		fclose($h);
		$num_days = count($dates);
		$avg = round($total_hits/$num_days);

		echo '<p><table width="40%"><th class="default_th">&nbsp;</th>
		<th class="default_th">Total</th><th class="default_th">Daily</th>'
		."<tr class='light_row'><td class='default_td'>Hits</td>
		<td class='default_td'>$total_hits</td><td class='default_td'>$avg"
		.'</td></tr><tr class="light_row"><td class="default_td">Unique Hits</td>
		<td class="default_td">'.count($unique_hits).'</td><td class="default_td">'
		.round(count($unique_hits)/$num_days)
		.'</td></tr></table>Percent Unique: '
		.number_format(count($unique_hits)/$total_hits*100, 1).'</p>';

		arsort($extensions);
		arsort($countries);

		$date_nums = array_values($dates);
		echo '<p><table width="75%" border="0"><tr><th class="default_th">Date</th>
		<th class="default_th">Hits That Day</th><th class="default_th">Change From Previous Day</th>
		<th class="default_th">Difference From Average ('.$avg.')</th></tr>';
		$i = 0;
		foreach ($dates as $day => $num)
		{
			$diff = $num - $avg;
			$change = (($i > 0) ? ($num - $date_nums[$i-1]) : 0);
			$change_color = get_change_color($change);
			$diff_color = get_change_color($diff);

			$class = (($i++%2) ? 'dark_row' : 'light_row');
			echo "<tr class='$class'><td class='default_td'>$day</td>
			<td class='default_td'>$num</td>
			<td class='default_td'>$change_color$change</font></td>
			<td class='default_td'>$diff_color$diff</font></td></tr>";
		}
		
		echo '</table></p><p><table width="75%" border="0">
		<tr><th class="default_th">Downloads based on file extensions</th>
		<th class="default_th">Total</th><th class="default_th">Daily</th></tr>';
		$i = 0;
		foreach ($extensions as $ext => $num)
		{
			$class = (($i++%2) ? 'dark_row' : 'light_row');
			echo "<tr class='$class'><td class='default_td'>$ext</td>
			<td class='default_td'>$num</td><td class='default_td'>"
			.number_format($num/$num_days, 1)."</td></tr>";
		}
		
		echo '</table></p><p><table width="75%" border="0"><tr>
		<th class="default_th">Hostname ISP extension</th>
		<th class="default_th">Total</th><th class="default_th">Daily</th></tr>';
		$i = 0;
		foreach ($countries as $c => $num)
		{
			$c_code = (isset($country_codes[strtolower($c)]) ? ' <font size="1">('.$country_codes[strtolower($c)].')</font>' : '');
			$class = (($i++%2) ? 'dark_row' : 'light_row');
			echo "<tr class='$class'><td class='default_td'>$c{$c_code}</td><td class='default_td'>$num</td><td class='default_td'>"
				.number_format($num/$num_days, 1)."</td></tr>\n";
		}
		echo '</table></p>';
	}
	else
	{
		echo '<table border="0" cellpadding="8" cellspacing="0">
		<tr class="paragraph"><td class="default_td">'
		."<form method='get' action='$this_file'>
		<input type='hidden' name='log' value='true' />";
		if ($index != '' && strpos($index, '?') !== false)
		{
			$id_temp = explode('=', $index, 2);
			$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
			echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
		}
		echo '<p>List the latest <input type="text" size="2" name="view" /> enties in the log file.<input class="button" type="submit" value="Go" /></p></form>
		<p>or <a class="default_a" href="'.$this_file.'log=true&amp;stats=true">view statistics</a>.</p></td></tr></table>';
	}
	echo '</p><p><a class="default_a" href="'.$this_file.'">Continue.</a></p>';
	show_footer();
	die();
}

if ($use_login_system && (isset($_POST['admin']) || isset($_GET['admin'])))
//user admin section
{
	echo $html_heading;
	show_header();
	if (!logged_in() || !is_admin())
	{
		echo '<p>You must be logged in as an admin to access this page.</p>';
	}
	else if (isset($_POST['username'], $_POST['password1'], $_POST['password2'], $_POST['admin']))
	{
		$pwd_reg_exp = '^[A-Za-z0-9_-]+$';
		if (strlen($_POST['password1']) < 6)
		{
			echo '<p>Password must be at least 6 characters long.</p>';
		}
		else if (!ereg($pwd_reg_exp, $_POST['username']))
		{
			echo "<p>The username must match the regular expression: <b>$pwd_reg_exp</b></p>";
		}
		else if ($_POST['password1'] != $_POST['password2'])
		{
			echo '<p>Passwords do not match.</p>';
		}
		else if (is_username($_POST['username']))
		{
			echo '<p>That username already exists.</p>';
		}
		else
		{
			$handle = @fopen($user_list, 'ab') or die("<p>Could not open file <i>$user_list</i> for writing.</p>");
			fwrite($handle, md5($_POST['password1']).$_POST['admin'].$_POST['username']."\n");
			fclose($handle);
			echo '<p>User added. <a class="default_a" href="'.$this_file.'">Continue.</a></p>';
		}
	}
	else if (isset($_POST['deluser'], $_POST['doit']))
	{
		if ($_POST['doit'])
		{
			if (is_user_admin($_POST['deluser']) && num_admins() < 2)
			{
				echo '<p>You cannot remove this user because it is the only admin.
				<br />Create another user with admin rights, then delete this user.</p>
				<p><a class="default_a" href="'.$this_file.'">Continue.</a></p>';
			}
			else
			{
				$users = @file($user_list) or die("<p>Could not open file <b>$user_list</b></p>");
				$handle = @fopen($user_list, 'wb') or die("<p>Could not open file <b>$user_list</b> for writing.</p>");
				$deluser = strtolower($_POST['deluser']);
				for ($i=0; $i<count($users); $i++)
				{
					if (strtolower(substr(rtrim($users[$i]), 33)) != $deluser)
					{
						fwrite($handle, $users[$i]);
					}
				}
				fclose($handle);
				echo '<p>User <b>'.$_POST['deluser'].'</b> has been removed. <a class="default_a" href="'
					.$this_file.'">Continue.</a></p>';
			}
		}
		else
		{
			echo '<p><table border="0" cellpadding="8" cellspacing="0"><tr class="paragraph"><td class="default_td">'
			.'Are you sure you want to remove <b>'.$_POST['deluser']."</b>?<p><form method='post' action='$this_file'>"
			.'<input type="hidden" name="doit" value="1" /><input type="hidden" name="admin" value="true" /><input type="hidden" name="deluser" value="'
			.$_POST['deluser'].'" /><input class="button" type="submit" value="Yes, do it." />'
			.'</form></td></tr></table></p>';
		}
	}
	else
	{
		$users = @file($user_list) or die("<p>Could not open file <b>$user_list</b></p>");
		echo "
		<p><table border='0' cellpadding='8' cellspacing='0'>
		<tr class='paragraph'><td class='default_td'>
		<h3>Add a user:</h3>
		<p><form method='post' action='$this_file'>
		<input type='hidden' name='admin' value='true' />
		Username: <input type='text' name='username' />
		<br />Password: <input type='password' name='password1' />
		<br />Password: <input type='password' name='password2' />
		<br />Is Admin?: <select name='admin'>
		<option selected value='0'>No</option><option value='1'>Yes</option></select>
		<p><input class='button' type='submit' value='Add User' />
		</form></p></td></tr></table><p>

		<p><table border='0' cellpadding='8' cellspacing='0'>
		<tr class='paragraph'><td class='default_td'>
		<h3>Delete a user:</h3>
		<p><form method='post' action='$this_file'>
		<input type='hidden' name='admin' value='true' />
		Select user to delete: <select name='deluser'>";
		for ($i=0; $i<count($users); $i++)
		{
			echo '<option>'.substr($users[$i], 33).'</option>';
		}
		echo '</select><input type="hidden" name="doit" value="0" />
		<p><input class="button" type="submit" value="Delete" /></form><p>
		</td></tr></table></p>';
	}
	show_footer();
	die();
}
else if ($use_login_system && isset($_GET['logout']))
//logout
{
	session_unset();
	session_destroy();
	redirect($this_file);
}
else if ($use_login_system && (isset($_POST['passwd']) || isset($_GET['passwd'])))
//change password
{
	echo $html_heading;
	show_header();
	if (!logged_in())
	{
		echo '<p>You must login to access this page.</p>';
	}
	else if (isset($_POST['oldpass'], $_POST['newpass1'], $_POST['newpass2']))
	{
		if (strlen($_POST['newpass1']) < 6)
		{
			echo '<p>New password too short (must be at least 6 characters).</p>';
		}
		else if ($_POST['newpass1'] != $_POST['newpass2'])
		{
			echo '<p>New passwords do not match.</p>';
		}
		else if (check_login($_SESSION['user'], md5($_POST['oldpass'])))
		{
			$users = @file($user_list) or die("<p>Could not open file <b>$user_list</b></p>");
			$handle = @fopen($user_list, 'wb') or die("<p>Could not open file <b>$user_list</b> for writing.</p>");
			$uuser = strtolower($_SESSION['user']);
			for ($i=0; $i<count($users); $i++)
			{
				fwrite($handle, ((strtolower(substr(rtrim($users[$i]), 33)) == $uuser) ?
					md5($_POST['newpass1']).substr($users[$i], 32) : $users[$i]));
			}
			fclose($handle);
			echo '<p>Password for <b>'.$_SESSION['user'].'</b> has been changed.<p>You must now <a class="default_a" href="'
				.$this_file.'">logout</a>.</p>';
		}
		else
		{
			echo '<p>Incorrect old password.</p>';
		}
	}
	else
	{
		echo "<p><table border='0' cellpadding='8' cellspacing='0'>
		<tr class='paragraph'><td class='default_td'>
		<form method='post' action='$this_file'>
		<input type='hidden' name='passwd' value='true' />
		Old Password: <input type='password' name='oldpass' />
		<br />New Password: <input type='password' name='newpass1' />
		<br />New Password: <input type='password' name='newpass2' />
		<p><input class='button' type='submit' value='Change Password' />
		</form></td></tr></table></p>";
	}
	show_footer();
	die();
}

$total_bytes = 0;

if ($links_file != '' && isset($_GET['link']))
//redirect to a link
{
	if (ok_to_log())
	{
		if ($log_file != '')
		{
			if ($write = @fopen($log_file, 'ab'))
			{
				fwrite($write, date('Y-M-d')."\t".date('H:i:s')
					."\t$ip\t$host\t$referrer\t"
					.$_GET['link']."\tLink file\n");
				fclose($write);
			}
		}
		if ($download_count != '')
		{
			add_to_file($_GET['link'], $download_count);
		}
	}
	redirect($_GET['link']);
}

if ($file_dl != '')
//if the user specified a file to download, download it now
{
	if (!is_file($dir.$file_dl))
	{
		echo $html_heading;
		show_header();
		echo '<h2>Error 404: file not found</h2>'
			.htmlentities($dir.$file_dl).' was not found on this server.';
		show_footer();
		die();
	}

	if ($anti_leech && !isset($_SESSION['ref']) && ($referrer == 'N/A' || !stristr($referrer, $_SERVER['SERVER_NAME'])))
	{
		if ($log_file != '' && ok_to_log())
		{
			if ($write = @fopen($log_file, 'ab'))
			{
				fwrite($write, date('Y-M-d')."\t".date('H:i:s')
					."\t$ip\t$host\t$referrer\t$dir$file_dl\tLeech Attempt\n");
				fclose($write);
			}
		}
		$ref = (($referrer == 'N/A') ? 'typing it in the address bar...' : $referrer);
		echo $html_heading;
		show_header();
		echo'<h2>This PHP Script has an Anti-Leech feature turned on.<p>Make sure you are accessing this file directly from <a class="default_a" href="http://'.$_SERVER['SERVER_NAME'].'">'
			.htmlentities($_SERVER['SERVER_NAME']).'</a></h2>'
			.'It seems you are trying to get it from <b>'."$ref</b><p>Your IP address has been logged.<br />$ip ($host)";
		$index_link = 'http://'.$_SERVER['SERVER_NAME'].$this_file.'dir='.translate_uri($subdir);
		echo '<p>Here is a link to the directory index the file is in:<br /><a class="default_a" href="'
			.$index_link.'">'.htmlentities($index_link).'</a></p>';
		show_footer();
		die();
	}
	
	if (ok_to_log())
	{
		if ($download_count != '')
		{
			add_to_file($dir.$file_dl, $download_count);
		}
		if ($log_file != '')
		{
			if ($write = @fopen($log_file, 'ab'))
			{
				fwrite($write, date('Y-M-d')."\t".date('H:i:s')
					."\t$ip\t$host\t$referrer\t$dir$file_dl\n");
				fclose($write);
			}
		}
	}

	if ($force_download) //use php to read the file, and tell the browser to download it
	{
		if (!($fn = @fopen($dir.$file_dl, 'rb')))
		{
			die($html_heading.'<h2>Error 401: permission denied</h2> you cannot access <i>'
				.htmlentities($file_dl).'</i> on this server.');
		}
		set_time_limit(0);
		header('Content-Length: '.filesize($dir.$file_dl));
		header('Content-Type: octet/stream');
		header('Content-Disposition: attachment; filename="'
			.get_basename($file_dl).'"');
		while (true)
		{
			$temp = @fread($fn, round($speed*1024));
			if ($temp == '')
			{
				break;
			}
			echo $temp;
			flush();
			if ($bandwidth_limit)
			{
				sleep(1);
			}
		}
		fclose($fn);
		die();
	}
	redirect(translate_uri($dir.$file_dl));
}

if ($log_file != '' && ok_to_log())
//write to the logfile
{
	if ($write = @fopen($log_file, 'ab'))
	{
		$log_str = date('Y-M-d')."\t".date('H:i:s')
			."\t$ip\t$host\t$referrer\t$dir";
		if ($search != '')
		{
			$log_str .= "\tSearch: $search";
		}
		fwrite($write, $log_str."\n");
		fclose($write);
	}
	else
	{
		echo '<p>Error: Could not write to logfile.</p>';
	}
}

if ($anti_leech && !isset($_SESSION['ref']))
{
	$_SESSION['ref'] = 1;
}

echo $html_heading;
show_header();

if (!is_dir($dir))
//make sure the subfolder exists
{
	echo '<p><b>Error: The folder <i>'.htmlentities($dir)
		.'</i> does not exist.</b></p>';
	$dir = $base_dir;
	$subdir = '';
}

if ($enable_searching && $search != '')
//show the results of a search
{
	echo '<p><table border="0" cellpadding="8" cellspacing="0">
		<tr class="paragraph"><td class="default_td"><b>'
		.$words['search results'].'</b> :<br /><font size="1">for <i>'
		.htmlentities($dir).'</i> and its subdirectories</font></p><p>';
	$results = search_dir($dir, $search);
	natcasesort($results);
	if ($_SESSION['sort'] == 'd' && $_SESSION['sortMode'] == 'f')
	{
			$results = array_reverse($results);
	}
	for ($i=0; $i<count($results); $i++)
	{
		$file = substr($results[$i], strlen($base_dir));
		echo '<a class="default_a" href="'.$this_file;
		if (is_dir($base_dir.$file))
		{
			echo 'dir='.translate_uri($file).'/">';
			if ($icon_path != '')
			{
				echo '<img border="0" height="16" width="16" alt="[dir]" src="'.$icon_path.'/dir.png" /> ';
			}
			echo htmlentities($file)."/</a><br />\n";
		}
		else if (ereg('\|$', $file))
		{
			$file = substr($file, 0, -1);
			$display = get_stored_info($file, $dir.$links_file);
			if ($display == '')
			{
				$display = $file;
			}
			echo 'dir='.translate_uri($subdir).'&amp;link='
			.translate_uri($file).'" title="Link to: '.$file.'">'
			.icon(ext($display)).htmlentities($display).'</a><br />';
		}
		else
		{
			echo 'dir='.translate_uri(dirname($file)).'/&amp;doc='
			.translate_uri(get_basename($file)).'">'
			.icon(ext($file)).htmlentities($file)."</a><br />\n";
		}
	}
	if (!count($results))
	{
		echo '</p><p><b>[ '.$words['no results'].' ]</b></p>';
	}
	echo '</p><p>'.$words['end of results'].' ('.count($results).' '
		.$words['found'].')</td></tr></table></p>';
	show_search_box();
	echo '<p><a class="default_a" href="'.$this_file.'dir='.translate_uri($subdir).'">Go back.</a></p>';
	show_footer();
	die();
}

//path navigation at the top
echo $words['index of'].' <a class="default_a" href="'.$this_file
//	.'dir=">'.htmlentities(substr(str_replace('/', ' / ', $base_dir), 0, -2)).'</a>/ ';
	 .'dir=">Documentos</a>/ ';
$exploded = explode('/', $subdir);
$c = count($exploded) - 1;
for ($i=0; $i<$c; $i++)
{
	echo '<a class="default_a" href="'.$this_file.'dir=';
	for ($j=0; $j<=$i; $j++)
	{
		echo translate_uri($exploded[$j]).'/';
	}
	echo '">'.htmlentities($exploded[$i]).'</a> / ';
}

//begin the table
echo "\n\n".'<table width="100%" border="0" cellpadding="0" cellspacing="2"><tr>';
table_heading($words['file'], 'f', 'Sort by Filename');
if ($show_type_column)
{
	table_heading('Type', 't', 'Sort by Type');
}
if ($download_count != '')
{
	table_heading('Downloads', 'h', 'Sort by Hits');
}
if ($show_size_column)
{
	table_heading($words['size'], 's', 'Sort by Size');
}
if ($show_date_column)
{
	table_heading($words['modified'], 'm', 'Sort by Date');
}
if ($description_file != '')
{
	table_heading('Description', 'd', 'Sort by Description');
}
echo '</tr>';

if ($subdir != '')
//if they are not in the root folder, have a link to the parent directory
{
	echo '<tr class="light_row"><td class="default_td" colspan="6"><a class="default_a" href="'.$this_file.'dir=';
	$subdir = substr($subdir, 0, -1);
	echo translate_uri(substr($subdir, 0, strrpos($subdir,'/'))).'/">';
	if ($icon_path != '')
	{
		echo "<img border=\"0\" height=\"16\" width=\"16\" src=\"$icon_path/back.png\" alt=\"[dir]\" /> ";
	}
	echo $words['parent directory'].'</a></td></tr>';
	$subdir .= '/';
}

flush();

$file_array = get_file_list($dir);
$size_array = $date_a_array = $date_m_array = $desc_array = $hit_array = $type_array = array();

$c = count($file_array);
for ($i=0; $i<$c; $i++)
{
	$thisf = $dir.$file_array[$i];
	if (ereg('\|$', $thisf)) //it is a link
	{
		$thisf = substr($thisf, 0, -1);
		$type_array[] = ($show_type_column ? ext(get_stored_info(substr($file_array[$i], 0, -1), $dir.$links_file)) : '');
		$hit_array[] = (($download_count != '' && !is_dir($thisf)) ? intval(get_stored_info(substr($file_array[$i], 0, -1), $download_count)) : 0);
		$date_m_array[] = 'N/A';
		$date_a_array[] = 'N/A';
		$size_array[] = '[Link]';
	}
	else //it is an actual file or folder
	{
		$size_array[] = ($show_size_column ? (is_dir($thisf) ? ($show_dir_size ? dir_size($thisf) : 0) : max(filesize($thisf), 0)) : 0);
		$type_array[] = (($show_type_column && !is_dir($thisf)) ? ext($thisf) : '');
		$hit_array[] = (($download_count != '' && !is_dir($thisf)) ? intval(get_stored_info($thisf, $download_count)) : 0);
		if ($show_date_column)
		{
			$date_m_array[] = filemtime($thisf);
			$date_a_array[] = fileatime($thisf);
		}
		else
		{
			$date_m_array[] = 0;
			$date_a_array[] = 0;
		}
	}
	$desc_array[] = (($description_file == '') ? '' : get_stored_info($thisf, $description_file));
}

switch ($_SESSION['sortMode'])
{
	case 's':
		array_multisort($size_array, $file_array, $date_m_array,
			$date_a_array, $hit_array, $desc_array, $type_array);
		break;
	case 'm':
		array_multisort($date_m_array, $file_array, $size_array,
			$date_a_array, $hit_array, $desc_array, $type_array);
		break;
	case 'd':
		array_multisort($desc_array, $file_array, $date_m_array,
			$size_array, $date_a_array, $hit_array, $type_array);
		break;
	case 'h':
		array_multisort($hit_array, $file_array, $date_m_array,
			$size_array, $date_a_array, $desc_array, $type_array);
		break;
	case 't':
		array_multisort($type_array, $file_array, $hit_array,
			$date_m_array, $size_array, $date_a_array, $desc_array);
}

if ($_SESSION['sort'] == 'd')
//if the current sort mode is set to descending, reverse all the arrays
{
	$file_array = array_reverse($file_array);
	$size_array = array_reverse($size_array);
	$date_m_array = array_reverse($date_m_array);
	$date_a_array = array_reverse($date_a_array);
	$desc_array = array_reverse($desc_array);
	$hit_array = array_reverse($hit_array);
	$type_array = array_reverse($type_array);
}

$folder_count = $file_count = $dl_count = 0;

for ($i=0; $i<$c; $i++)
//display the list of files
{
	$value = $file_array[$i];
	echo "\n<tr class=".(($i % 2 == ($subdir == '')) ? '"dark_row">' : '"light_row">');

	//file column
	echo '<td class="default_td" align="left" valign="top"><a class="default_a" href="'.$this_file;
	$npart = $dir.$value;
	if (ereg('\|$', $value)) //it is a link, not an actual file
	{
		$value = substr($value, 0, -1);
		$npart = substr($npart, 0, -1);
		$display = get_stored_info($value, $dir.$links_file);
		if ($display == '')
		{
			$display = $value;
		}
		echo 'dir='.translate_uri($subdir).'&amp;link='
			.translate_uri($value).'" title="Link to: '.$value.'">'
			.icon(ext($display)).htmlentities($display).'</a>';
	}
	else //it is a real file or folder
	{
		if (is_dir($npart))
		{
			$folder_count++;
			if ($icon_path != '')
			{
				if ($folder_expansion)
				{
					$listVal = (in_array($npart, $_SESSION['expanded']) ? 'collapse' : 'expand');
					echo 'dir='.translate_uri($subdir)."&amp;$listVal=".translate_uri($value).'">'
					.'<img border="0" height="16" width="16" alt="[dir]" src="'.$icon_path.'/dir.png" /></a> '
					.'<a class="default_a" href="'.$this_file.'dir='
					.translate_uri($subdir.$value).'/">';
				}
				else
				{
					echo 'dir='.translate_uri($subdir.$value).'/">'
					.'<img border="0" height="16" width="16" alt="[dir]" src="'.$icon_path.'/dir.png" /> ';
				}
			}
			else
			{
				echo 'dir='.translate_uri($subdir.$value).'/">';
			}
			echo htmlentities($value).'</a>';
			if ($show_folder_count)
			{
				$n = num_files($npart);
				$s = (($n == 1) ? $words['file'] : $words['files']);
				echo " [$n $s]";
			}
		}
		else //is a file
		{
			$file_count++;
			echo 'dir='.translate_uri($subdir).'&amp;doc='	////////////////////////////	CHANGED TO DOC KS
			.translate_uri($value)."\">"
			.icon(ext($npart)).htmlentities($value).'</a>';
			if ($md5_show && $size_array[$i]>0 && $size_array[$i]/1048576 <= $md5_show)
			{
				echo ' [<a class="default_a" href="'.$this_file
				.'dir='.translate_uri($subdir).'&amp;md5='
				.translate_uri($value).'"><font size="1">get md5sum</font></a>]';
			}
		}
		if ($use_login_system && logged_in() && is_admin())
		{
			echo ' [<a class="default_a" href="'.$this_file.'dir='.translate_uri($subdir)
			.'&amp;delete='.translate_uri($value).'"><font size="1">delete</font></a>, '
			.'<a class="default_a" href="'.$this_file.'dir='.translate_uri($subdir)
			.'&amp;rename='.translate_uri($value).'"><font size="1">rename/move</font></a>]';
		}
		$age = (time() - $date_m_array[$i]) / 86400;
		$age_r = round($age, 1);
		$s = (($age_r == 1) ? '' : 's');
		if ($days_new && $age <= $days_new)
		{
			echo (($icon_path == '') ? ' <font color="#FF0000" size="1">[New]</font>'
				: ' <img border="0" alt="'."$age_r day$s".' old" height="14" width="28" src="'.$icon_path.'/new.png" />');
		}
		if ($folder_expansion && is_dir($npart) && in_array($npart, $_SESSION['expanded']))
		{
			$ex_array = get_file_list($npart);
			if ($_SESSION['sort'] == 'd' && $_SESSION['sortMode'] == 'f')
			{
					$ex_array = array_reverse($ex_array);
			}
			echo '<ul>';
			for ($j=0; $j<count($ex_array); $j++)
			{
				$element = $ex_array[$j];
				echo '<li><a class="default_a" href="'.$this_file
					.((is_file("$npart/$element")) ? 'dir='.translate_uri($subdir.$value).'/&amp;doc='
					.translate_uri($element).'">' : 'dir='.translate_uri("$subdir$value/$element/").'">');
				if (is_file("$npart/$element"))
				{
					echo icon(ext($element));
				}
				else if ($icon_path != '')
				{
					echo '<img border="0" height="16" width="16" alt="[dir]" src="'
						.$icon_path.'/dir.png" /> ';
				}
				echo htmlentities($element)."</a></li>\n";
			}
			echo '</ul>';
		}
	}
	if ($use_login_system && $description_file != '' && logged_in() && is_admin())
	//"edit description" link
	{
		echo ' [<a class="default_a" href="'.$this_file.'dir='
		.translate_uri($subdir).'&amp;descFile='.translate_uri($value)
		.'"><font size="1">change description</font></a>]';
	}
	
	if ($thumbnail_height > 0 && in_array(ext($value), array('png', 'jpg', 'jpeg', 'gif')) && is_file($npart))
	//display the thumbnail image
	{
		echo ' <a href="'.$this_file.'dir='.translate_uri($subdir).'&amp;doc='
		.translate_uri($value).'"><img border="0" src="'.$this_file
		.'dir='.translate_uri($subdir).'&amp;thumbnail='.translate_uri($value)
		.'" alt="Thumbnail of '.$value.'" /></a>';
	}
	
	echo '</td>'; //end filename column
	
	//filetype column
	if ($show_type_column)
	{
		echo '<td class="default_td" align="left" valign="top">'
		.(($type_array[$i] == '') ? '&nbsp;' : htmlentities($type_array[$i])).'</td>';
	}

	//hits column
	if ($download_count != '')
	{
		$dl_count += $hit_array[$i];
		echo '<td class="default_td" align="right" valign="top">'
		.((!is_dir($npart)) ? $hit_array[$i] : '&nbsp;').'</td>';
	}

	//size column
	if ($show_size_column)
	{
		echo '<td class="default_td" align="right" valign="top">';
		$ds = $size_array[$i];
		if ($ds === '[Link]')
		{
			echo $ds;
		}
		else
		{
			$total_bytes += $ds;
			$size_h = get_filesize($ds);
			echo (is_dir($npart) ?
			($show_dir_size ? "<a title=\"$value/\n".number_format($ds, 0, '.', ',')." bytes ($size_h)\">$size_h</a>" : '[dir]')
			: "<a title=\"$value\n".number_format($ds, 0, '.', ',')." bytes ($size_h)\">$size_h</a>");
		}
		echo '</td>';
	}

	//date column
	if ($show_date_column)
	{
		echo '<td class="default_td" align="right" valign="top">';
		if ($date_a_array[$i] == 'N/A')
		{
			echo 'N/A';
		}
		else
		{
			$a = date('Y-M-d h:i:s A', $date_a_array[$i]);
			$m = date('Y-M-d h:i:s A', $date_m_array[$i]);
			echo "<a title=\"$value\nLast Modified: $m\nLast Accessed: $a\">"
				.date('Y-M-d', $date_m_array[$i]).'</a>';
		}
		echo '</td>';
	}
	
	//description column
	if ($description_file != '')
	{
		echo '<td class="default_td" align="left" valign="top">'
			.(($desc_array[$i] != '') ? $desc_array[$i] : '&nbsp;').'</td>';
	}
	
	echo "</tr>\n";
}

//footer of the table
echo '<tr><th class="default_th"><font size="1">'."\n$file_count "
	.$words[(($file_count == 1) ? 'file' : 'files')]
	." - $folder_count ".$words['folders'].'</font></th>';
if ($show_type_column)
{
	echo "<th class='default_th'>&nbsp;</th>";
}
if ($download_count != '')
{
	echo "<th class='default_th'><font size='1'>Total: $dl_count</font></th>";
}
if ($show_size_column)
{
	echo '<th class="default_th"><font size="1">'.$words['total size'].': <a title="'.$words['total size'].":\n"
		.number_format($total_bytes, 0, '.', ',').' bytes ('.get_filesize($total_bytes).')">'
		.get_filesize($total_bytes)."</a></font></th>\n";
}
if ($show_date_column)
{
	echo '<th class="default_th">&nbsp;</th>';
}
if ($description_file != '')
{
	echo '<th class="default_th">&nbsp;</th>';
}
// echo '</tr></table><div align="right"><font size="1">Powered by <a class="default_a" href="http://autoindex.sourceforge.net/">AutoIndex PHP Script</a></font></div>';
		/*
		 * We request that you do not remove the link to the AutoIndex website.
		 * This not only gives respect to the large amount of time given freely by the
		 * developer, but also helps build interest, traffic, and use of AutoIndex.
		 */

echo "\n".'<table width="100%" border="0" cellpadding="0" cellspacing="2"><tr><td>';
if ($enable_searching)
{
	show_search_box();
}

if ($use_login_system)
{
	if (!logged_in())
	{
		echo '</td><td>';
		show_login_box();
	}
	else //show user options
	{
		echo '<p><table border="0" cellpadding="8" cellspacing="0"><tr class="paragraph"><td class="default_td">';
		if (is_admin())
		{
			echo '<p><a class="default_a" href="'.$this_file.'config=true">Reconfigure script</a></p>'
			.'<p><a class="default_a" href="'.$this_file.'admin=true">User account management</a>'
			.'<br /><a class="default_a" href="'.$this_file.'log=true">Log file viewer / statistics</a>'
			.'<br /><a class="default_a" href="'.$this_file.'edit_links=true&amp;dir='.translate_uri($subdir).'">Links file editor</a>'
			.'<br /><a class="default_a" href="'.$this_file.'edit_ban=true">Edit ban list</a></p>'
			.'<p><a class="default_a" href="'.$this_file.'getcreate=true&amp;dir='.translate_uri($subdir).'">Create a folder (in current directory)</a>'
			.'<br /><a class="default_a" href="'.$this_file.'copyURL=true&amp;dir='.translate_uri($subdir).'">Copy a remote file (to current directory)</a></p>';
		}
		echo '<p><a class="default_a" href="'.$this_file
		.'passwd=true">Change password</a><br /><a class="default_a" href="'.$this_file
		.'logout=true">Log out [ '.$_SESSION['user'].' ]</a></p></td></tr></table></p>';
	}
}
echo '</td></tr></table>';

if ($allow_uploads && (!$use_login_system || logged_in()))
{
	echo "<p><form method='post' action='$this_file'>
	<input type='hidden' name='dir' value='$subdir' />
	Para Subir <select size='1' name='numUpload'>";
	for ($i=1; $i<=10; $i++)
	{
		echo "\t<option>$i</option>\n";
	}
	echo '</select> archivo(s) a esta carpeta, Haz click <input type="submit" value="Aqu�" /></form></p>';
}

if ($select_language)
{
	echo '<p><div align="left"><font size="2">Select Language:'
		."<form method='get' action='$this_file'><select name='lang'>";
	$l = get_all_files($path_to_language_files);
	sort($l);
	for ($i=0; $i<count($l); $i++)
	{
		if (is_file($path_to_language_files.$l[$i]) &&
			eregi('^[a-z]{2}(_[a-z]{2})?\.php$', $l[$i]))
		{
			$f = substr(get_basename($l[$i]), 0, -4);
			$sel = (($f == $_SESSION['lang']) ? ' selected' : '');
			echo "\t<option$sel>$f</option>\n";
		}
	}
	echo '</select><input type="submit" value="Change" />';
	if ($index != '' && strpos($index, '?') !== false)
	{
		$id_temp = explode('=', $index, 2);
		$id_temp[0] = substr(strstr($id_temp[0], '?'), 1);
		echo "<input type='hidden' name='$id_temp[0]' value='$id_temp[1]' />";
	}
	echo '</form></font></div></p>';
}

show_footer();

//find time it took for the page to generate, in milliseconds
$page_time = round((get_microtime() - $start_time) * 1000, 1);


if ($index == '')
{
	//echo 'aa</body></html>';
}





/*ESTE ARCHIVO TE PERMITE REALIZAR TODA LA PARTE INFERIOS*/
/*Y LOS BLOQUES DEL LUGAR DERECHO                        */
include(XOOPS_ROOT_PATH."/footer.php");

?>